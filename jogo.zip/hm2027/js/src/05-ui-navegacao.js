  // ============================= 05-ui-navegacao.js =============================
  // Navegação e UI geral (seleção de clube, plantel, importação, ficha de jogador)
  // Team select screen
  // =================================================================
  const teamGrid = document.getElementById("teamGrid");
  const COMPETITION_LABELS = {
    "placard-2026-27":"Campeonato Placard",
    "2div-norte-2026-27":"CN 2.ª Divisão Norte",
    "2div-sul-2026-27":"CN 2.ª Divisão Sul",
    "3div-norte-a-2026-27":"CN 3.ª Divisão Norte A",
    "3div-norte-b-2026-27":"CN 3.ª Divisão Norte B",
    "3div-sul-a-2026-27":"CN 3.ª Divisão Sul A",
    "3div-sul-b-2026-27":"CN 3.ª Divisão Sul B",
    "3div-apuramento-campeao-2026-27":"CN 3.ª Divisão Apuramento Campeão",
    "3div-apuramento-promocao-2026-27":"CN 3.ª Divisão Apuramento Promoção",
    "supertaca":"Supertaça António Livramento",
    "ok-liga-2026-27":"OK Liga",
    "serie-a1-2026-27":"Serie A1",
    "copa-del-rey":"Copa del Rey",
    "coppa-italia":"Coppa Italia",
    "supercopa-espana":"Supercopa de España",
    "supercoppa-italiana":"Supercoppa Italiana",
    "europa-qualificacao":"Ronda de Qualificação Europeia",
    "europa-champions":"WSE Champions League",
    "europa-cup":"WSE Cup",
    "europa-trophy":"WSE Trophy",
  };
  let selectedNewGameCompetitionId = "placard-2026-27";
  // Novo passo "País": escolhido antes do ecrã de seleção de competição/clube, para que a OK
  // Liga (e, desde 2026-09-06, a Serie A1) nunca apareçam listadas como "mais uma competição" ao
  // lado das portuguesas — ver countrySelectOverlay em index.html e o clique em
  // mgrNameContinueBtn (12-arranque.js).
  let selectedNewGameCountry = "pt";

  function clubDefinitionCompetitionId(def){
    if(def.pais==="es") return "ok-liga-2026-27";
    if(def.pais==="it") return "serie-a1-2026-27";
    if(def.divisaoAtual==="2div") return "2div-"+(def.zona==="sul"?"sul":"norte")+"-2026-27";
    // 3ª Divisão: nunca escolhível (sem botão de seleção próprio), mas tem de mapear para um id
    // que não seja "placard-2026-27" — caso contrário, os clubes da 3ª apareciam misturados no
    // ecrã de seleção do Placard, já que esta função é usada como filtro por competição.
    if(def.divisaoAtual==="3div") return "3div-"+def.zona+"-2026-27";
    return "placard-2026-27";
  }
  function competitionLabel(compId){ return COMPETITION_LABELS[compId] || compId; }
  // Correção (2026-09-14, pedido do utilizador: "os jogadores e as competições devem ser sempre
  // clicaveis, mesmo nas noticias"): tal como playerLinkHtml (01-nucleo.js) para jogadores, este é
  // o ponto único a usar sempre que o nome de uma competição aparece em texto (notícias incluídas)
  // — produz um botão com um listener GLOBAL delegado (mais abaixo) que salta diretamente para o
  // separador Competições, já na competição indicada (mesmo mecanismo de state.viewedCompetitionId
  // já usado pelo seletor de país/competição e pelos atalhos "ver competição" existentes).
  function competitionLinkHtml(competitionId, label){
    if(!competitionId) return escapeHtml(label||"");
    return `<button class="jr-competition-link" data-competition="${competitionId}">${escapeHtml(label||competitionLabel(competitionId))}</button>`;
  }
  function openCompetitionView(competitionId){
    playerModal.classList.add("hidden");
    state.viewedCompetitionId = competitionId;
    setView("competicoes");
  }
  // Correcao (2026-09-09): o menu "Competicoes" (viewCompeticoes) listava tudo junto, sem
  // distincao de pais, e nunca incluia OK Liga/Serie A1 -- pedido do utilizador para poder
  // escolher primeiro o pais e depois a respectiva competicao. Esta estrutura agrupada alimenta
  // tanto o novo seletor de pais como o repovoamento do seletor de competicao (ver
  // populateCompetitionViewCountrySelect/populateCompetitionViewSelectForCountry, 10-estatisticas.js).
  const COMPETITION_VIEW_GROUPS = [
    { pais:"pt", label:"Portugal", competitions: [
        { id:"placard-2026-27", label:"Campeonato Placard" },
        { id:"2div-norte-2026-27", label:"CN 2.ª Divisão Norte" },
        { id:"2div-sul-2026-27", label:"CN 2.ª Divisão Sul" },
        { id:"3div-norte-a-2026-27", label:"CN 3.ª Divisão Norte A" },
        { id:"3div-norte-b-2026-27", label:"CN 3.ª Divisão Norte B" },
        { id:"3div-sul-a-2026-27", label:"CN 3.ª Divisão Sul A" },
        { id:"3div-sul-b-2026-27", label:"CN 3.ª Divisão Sul B" },
        { id:"taca-portugal", label:"Taça de Portugal" },
        { id:"supertaca", label:"Supertaça António Livramento" },
        { id:"elite-cup", label:"Elite Cup" },
      ] },
    { pais:"es", label:"España", competitions: [
        { id:"ok-liga-2026-27", label:"OK Liga" },
        { id:"copa-del-rey", label:"Copa del Rey" },
        { id:"supercopa-espana", label:"Supercopa de España" },
      ] },
    { pais:"it", label:"Italia", competitions: [
        { id:"serie-a1-2026-27", label:"Serie A1" },
        { id:"coppa-italia", label:"Coppa Italia" },
        { id:"supercoppa-italiana", label:"Supercoppa Italiana" },
      ] },
    // Europa (07g-europa.js): quarto grupo permanente, sempre visível no menu de Competições,
    // independentemente de o clube do utilizador se qualificar ou não nesta época (pedido
    // explícito do utilizador — ver estudo, secção 4/ponto 6).
    { pais:"eu", label:"Europa", competitions: [
        { id:"europa-qualificacao", label:"Ronda de Qualificação" },
        { id:"europa-champions", label:"WSE Champions League" },
        { id:"europa-cup", label:"WSE Cup" },
        { id:"europa-trophy", label:"WSE Trophy" },
      ] },
    // Seleções Nacionais (2026-09-26): não jogável, só resultados — grupo próprio sempre visível
    // (mesmo antes de qualquer edição ter corrido), tal como o grupo "Europa" acima.
    { pais:"selecoes", label:"Seleções", competitions: [
        { id:"selecoes-mundial", label:"Campeonato do Mundo" },
        { id:"selecoes-europeu", label:"Campeonato da Europa" },
      ] },
  ];
  function competitionViewCountryForId(compId){
    for(const g of COMPETITION_VIEW_GROUPS){ if(g.competitions.some(c=>c.id===compId)) return g.pais; }
    return "pt";
  }
  function renderTeamSelect(compId){
    selectedNewGameCompetitionId = compId || selectedNewGameCompetitionId;
    const comp = state.competitions[selectedNewGameCompetitionId];
    document.querySelectorAll(".competition-picker-btn").forEach(btn=>btn.classList.toggle("active",btn.getAttribute("data-competition")===selectedNewGameCompetitionId));
    const heading=document.getElementById("teamSelectHeading");
    const selectableCount = comp ? comp.teamIds.filter(id=>!isBTeamId(id)).length : 0;
    if(heading) heading.textContent=competitionLabel(selectedNewGameCompetitionId)+" · "+selectableCount+" clubes";
    teamGrid.innerHTML = "";
    // Correção (pedido do utilizador): no Campeonato Placard (divisão de topo), o rótulo de
    // reputação passa a ser relativo aos outros clubes desta mesma divisão nesta carreira, em
    // vez da escala global fixa — ver placardContextualReputationLabel em 01-nucleo.js. As
    // restantes divisões (2ª Divisão Norte/Sul) mantêm-se inalteradas, com a escala global.
    const isPlacard = selectedNewGameCompetitionId === "placard-2026-27";
    const placardPool = isPlacard && comp
      ? comp.teamIds.filter(id=>!isBTeamId(id)).map(id=>{
          const clubDef = CLUB_DEFS.find(d=>d.id===id);
          return { id, rep: normalizeClubReputation(clubDef&&clubDef.reputacao, clubDef||{}) };
        })
      : null;
    CLUB_DEFS.filter(def=>clubDefinitionCompetitionId(def)===selectedNewGameCompetitionId && !isBTeamId(def.id)).forEach(def => {
      const card = document.createElement("div");
      card.className = "team-card";
      const defRep = normalizeClubReputation(def.reputacao, def);
      const bandLabel = placardPool ? placardContextualReputationLabel(def.id, placardPool) : reputationBandLabel(defRep);
      const crestUrl = clubCrestUrl(def.id);
      const dotHtml = crestUrl
        ? `<div class="dot has-crest"><img src="${crestUrl}" alt="" class="crest-img"></div>`
        : `<div class="dot" style="background:${def.color}"></div>`;
      card.innerHTML = `${dotHtml}<div><div class="name">${escapeHtml(def.name)}</div><div class="tier">${defRep} · ${bandLabel}</div></div>`;
      card.addEventListener("click", () => { const f = () => chooseClub(def.id, selectedNewGameCompetitionId); if(window.hm2027Pensar) window.hm2027Pensar(f); else f(); });
      teamGrid.appendChild(card);
    });
  }
  document.querySelectorAll(".competition-picker-btn").forEach(btn=>btn.addEventListener("click",()=>renderTeamSelect(btn.getAttribute("data-competition"))));

  function chooseClub(id, competitionId){
    const compId = competitionId || clubDefinitionCompetitionId(CLUB_DEFS.find(d=>d.id===id)||{});
    const chosenCompetition = state.competitions[compId];
    if(!chosenCompetition || !chosenCompetition.teamIds.includes(id)){
      alert("O clube selecionado não pertence à competição escolhida.");
      return;
    }
    state.userCompetitionId = compId;
    state.viewedCompetitionId = compId;
    state.userTeamId = id;
    if(window.hm2027NovaCarreira) window.hm2027NovaCarreira();   // nova carreira: ainda não há ficheiro de gravação atual
    state.teams[id].provisional = false;
    // Semente de carreira (2026-09-17, pedido do utilizador: "as transferencias estao a
    // repetir-se bastante cada vez que inicio o jogo"): os plantéis placeholder são gerados de
    // forma inteiramente determinística (makeSeededRng(id+"|"+nome), sem Math.random() nenhum) e
    // a seleção de candidatos da IA no mercado (tryPurchase/tryBTeam/tryFreeAgent/tryLoan,
    // 04-financas.js) também era 100% determinística — estado inicial idêntico + seleção sempre
    // igual = quase os mesmos negócios em todas as carreiras novas. state.gameSeed usa
    // Math.random() (a única fonte de entropia real já usada no jogo, nos "gates" de tentativa de
    // mercado) uma única vez por carreira, e passa a entrar no sorteio de pequenas variações de
    // pontuação entre candidatos (ver aiCandidateScoreJitter) — diferente a cada carreira nova,
    // mas continua tudo determinístico DENTRO da mesma carreira (mesmo save reproduz sempre o
    // mesmo resultado).
    state.gameSeed = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
    document.getElementById("teamSelectOverlay").classList.add("hidden");
    state.season = 1; state.seasonOver=false; state.playoffActive=false; state.playoffClinchedAnnounced=false;
    state.seasonOverSinceDate=null; state.seasonCloseStuckWarned=false;
    state.viewHistory=[];
    Object.values(state.competitions).forEach(comp=>{
      comp.epoca=state.season; comp.fixtures=generateValidatedFixtures(comp.teamIds);
      comp.currentRound=0; comp.playoff=null; comp.status="regular";
      assignFixtureDatesFor(comp);
    });
    resetStats(); rebuildGlobalAgenda();
    state.news = [];
    Object.values(state.teams).forEach(initClubFinance);
    Object.values(state.teams).forEach(normalizeInitialWageBill);
    Object.values(state.teams).forEach(initTacticalIdentity);
    // Correção: state.currentDate só era definido mais abaixo (15 de julho, fixo) — mas
    // initTacaPortugal/initSupertaca (e agora initEliteCup) já publicam notícias e, no caso da
    // Elite Cup, resolvem mesmo jogos nesta função, todos a usar state.currentDate. Sem esta
    // atribuição adiantada, essas primeiras notícias/jogos da carreira ficavam datados de
    // 1 de janeiro de 1970 (new Date(null)).
    // Correção (calendário sem saltos, pedido explícito do utilizador, 2026-09-14: "o jogo deve
    // começar no dia 1 de setembro"): a data de arranque já tinha sido corrigida de um "15 de
    // julho" fixo para "1 semana antes dos quartos de final da Elite Cup" — mas isso ainda
    // dependia da Elite Cup, sem significado próprio. Agora que a Elite Cup passou para o fim de
    // setembro e o salto de calendário entre o fim da Elite Cup e a 1ª jornada do campeonato foi
    // removido (ver finalizePreSeasonLeagueStart, mais abaixo), a época pode começar mesmo a 1 de
    // setembro (seasonStartDate, 01-nucleo.js), sem depender de mais nada — o tempo passa sempre
    // dia a dia a partir daqui, através da Elite Cup, até à 1ª jornada em outubro.
    state.currentDate = seasonStartDate(state.season);
    initTacaPortugal();
    // Supertaça António Livramento: a 1.ª carreira não tem época anterior para apurar
    // campeão/vencedor da Taça — usa o par inaugural fixo do roteiro de implementação
    // (Benfica vs. Sporting), sempre em campo neutro, tal como qualquer outra edição.
    initSupertaca({ initialEditionOverride: true });
    // Elite Cup (07d-elite-cup.js): joga-se logo no arranque da carreira, antes de a pré-época
    // de mercado abrir (roteiro: "início da carreira, Elite Cup, Supertaça, Campeonato
    // Placard") — a 1.ª carreira não tem época anterior para apurar os 8 qualificados, usa-se a
    // classificação histórica fixa do roteiro de implementação.
    initEliteCup({ initialEditionOverride: true });
    // Copa del Rey/Coppa Italia (07e-copas-nacionais.js): apuram-se sozinhas a meio da 1ª época,
    // assim que a OK Liga/Serie A1 completarem a 1ª volta — nada a inicializar aqui.
    // Supercopa de España e Supercoppa Italiana (07f-supertacas-internacionais.js): tal como a
    // Supertaça portuguesa, a 1.ª carreira de sempre não tem época anterior — usam-se os
    // resultados REAIS da época 2025-26 (confirmados com fontes, ver o próprio ficheiro).
    initSupercopaEspana({ initialEditionOverride: true });
    initSupercoppaItaliana({ initialEditionOverride: true });
    // Competições Europeias (07g-europa.js): 1ª edição usa o sorteio real 2026-27 (potes da
    // Champions League) — a Cup/Trophy/Qualificação da 1ª edição não têm dados reais
    // equivalentes disponíveis, por isso usam o mesmo mecanismo simulado das edições seguintes.
    europaInitEdition({ initialEditionOverride: true });
    // Seleções Nacionais (07h-selecoes.js): correção (pedido explícito do utilizador, 2026-09-27:
    // "o jogo tem de começar com o campeonato do mundo", "em setembro") — antes desta correção,
    // a resolução da 1ª edição (sempre o Mundial) só corria dentro de beginDefeso()
    // (08-evolucao-jogadores.js), ou seja, no FIM da época 1 (já dentro do defeso seguinte), nunca
    // no arranque da carreira propriamente dito. O Mundial disputa-se na realidade a 16-21 de
    // setembro, antes mesmo de a Elite Cup arrancar (fim de setembro) — cabe dentro da mesma
    // janela livre de pré-época já usada pelas outras provas iniciadas acima. refSeason=0 pede
    // explicitamente as datas/rótulos da época 1 (seasonStartDate(1)) — sem isto, sairia "época 2"
    // (state.season já é 1 neste ponto, ver selecaoTorneioDates em 07h-selecoes.js).
    // Correção (mesmo dia, pedido seguinte: "o jogo tem de começar com a noticia da
    // convocatória... depois vemos as noticias dos jogos"): prepareSelecoesEdicaoForNewSeason só
    // seleciona os convocados e monta o calendário — announceSelecoesEdicaoIfPending publica a
    // notícia de sorteio+convocatória já datada de state.currentDate (hoje, 1 de setembro), e cada
    // jornada/eliminatória só se resolve e publica a sua própria notícia dia a dia, à medida que o
    // calendário lá chega (ver processSelecoesForCurrentDate, chamada a partir de
    // processPhaseFiveFinalsForCurrentDate, 07-playoff.js).
    if(typeof prepareSelecoesEdicaoForNewSeason==="function"){
      prepareSelecoesEdicaoForNewSeason(0);
      announceSelecoesEdicaoIfPending();
    }
    // Correção: reputacaoJogador nunca vinha preenchido na base de dados inicial — só era
    // calculado no fim de cada época, ou ao carregar um save antigo. Isto significava que,
    // durante toda a 1ª época de qualquer carreira nova, TODOS os jogadores (por mais títulos,
    // internacionalizações ou OVR que tivessem) eram tratados como anónimos nas regras que
    // dependem da reputação individual (ex.: limite de distância entre clubes num empréstimo),
    // permitindo emprestar veteranos muito decorados para clubes claramente pequenos demais só
    // por a reputação ainda não ter sido calculada uma primeira vez.
    Object.values(state.teams).forEach(t=>t.players.forEach(p=>{ p.reputacaoJogador = computePlayerReputation(p); }));
    // Os salários iniciais (generateContract) são atribuídos durante a construção do plantel,
    // altura em que a reputação do jogador ainda é sempre 0 (só é calculada acima, depois de
    // todos os plantéis existirem). Sem este recálculo, o bónus salarial por reputação (só
    // relevante na Placard, para jogadores já consagrados) nunca chegava a ser aplicado no
    // início de qualquer carreira. Só corre uma vez, no arranque da carreira, antes de
    // qualquer contrato ser negociado.
    Object.values(state.teams).forEach(t=>t.players.forEach(p=>{
      if(!p.contrato) return;
      p.contrato.salarioMensal = divisionSalaryEstimate(overall(p), p.reputacaoJogador||0, p.age, t.divisaoAtual);
    }));
    // Academia e Juvenis: arranca a academia dos clubes elegíveis já com os 4 escalões
    // preenchidos (decisão 3 do utilizador — nunca à espera de vários anos). initAcademyLevel
    // (chamada de dentro de bootstrapAcademyIfEmpty) substitui a antiga initFormationQuality,
    // removida na Fase 5 (2026-09-22).
    Object.values(state.teams).forEach(bootstrapAcademyIfEmpty);
    // Staff — Treinadores (2026-09-22, pedido do utilizador): mesma regra de elegibilidade e
    // mesmo momento de arranque da Academia (08c-staff-treinadores.js).
    Object.values(state.teams).forEach(bootstrapTreinadorIfEmpty);
    // Fase 15: a carreira começa em plena pré-época/defeso (mercado aberto a transferências),
    // para poderes reforçar o plantel antes da 1ª jornada — só quando avanças é que a época
    // "oficialmente" começa e o calendário passa a correr dia a dia.
    state.pendingSeasonStartDate = addDays(state.fixtures[0].date, -5);
    // Correção (pedido do utilizador): antes, um clube apurado para a 1.ª edição da Elite Cup
    // (os 8 do roteiro, ver ELITE_CUP_INITIAL_RANKING) saltava logo para a prova, sem NENHUMA
    // janela de mercado antes — só via a pré-época depois de a Elite Cup terminar por completo
    // (várias eliminatórias seguidas, tudo interativo). Passa a abrir-se sempre a pré-época já
    // aqui, mesmo para quem vai disputar a Elite Cup: uma janela curta antes de a prova arrancar,
    // para reforçar o plantel primeiro. Só quando o utilizador clicar em "Iniciar a Época" é que
    // a Elite Cup se resolve (ver finalizePreSeasonDefeso/finalizePreSeasonLeagueStart, abaixo, e
    // eliteCupRunPostSequence em 07d-elite-cup.js). Para clubes fora da Elite Cup, o efeito é
    // impercetível — a prova resolve-se na mesma, só que um clique depois, sempre 100% invisível
    // (nenhuma eliminatória deles envolve o utilizador).
    initPreSeasonPlan();
    startPreSeasonDefeso();
    setView("clube"); renderAll();
  }

  // Fase 15: ecrã de pré-época — igual em espírito ao defeso entre épocas, mas sem resumo de
  // campeão/promoções (a época ainda nem começou). Mostra o mercado aberto e deixa o utilizador
  // negociar livremente antes de a 1ª jornada arrancar.
  function startPreSeasonDefeso(){
    state.inDefeso = true;
    state.isPreSeasonDefeso = true;
    state.marketLastRefreshSeason = null;
    generateAiOffersForUser(true);
    const continuarBtnEl=document.getElementById("continuarBtn");
    if(continuarBtnEl){ continuarBtnEl.disabled=false; continuarBtnEl.textContent="Iniciar a Época"; }
    renderPreSeasonModal();
  }
  function renderPreSeasonModal(){
    const modal=document.getElementById("defesoModal"), body=document.getElementById("defesoModalBody");
    if(!modal||!body) return;
    // Correção (pedido do utilizador, 2026-09-14: "o defeso como antigamente deixou de fazer
    // sentido" — agora que negociar é possível o ano inteiro, com janelas reais de inscrição em
    // vez de um período isolado antes da época): o título deste ecrã deixa de dizer "Defeso",
    // passando a refletir o que o corpo do modal já mostra — pré-época, aqui, ou fim de época
    // normal em renderDefesoModal (08-evolucao-jogadores.js). O ecrã em si mantém-se (resumo +
    // botão para avançar), só a moldura "Defeso" é que desaparece.
    const titleEl = document.getElementById("defesoModalTitle"); if(titleEl) titleEl.textContent = "Pré-Época";
    const team=myTeam();
    initClubFinance(team);
    // Correção (pedido do utilizador): quando a Elite Cup desta carreira ainda não está
    // concluída, esta é só a janela CURTA de mercado antes de a prova arrancar — avisa disso
    // explicitamente (em vez de dar a entender que só falta a 1.ª jornada do campeonato), para
    // quem for um dos 8 apurados não ficar surpreendido ao clicar em "Iniciar a Época" e cair
    // logo na Elite Cup em vez do campeonato.
    const edicao = state.eliteCup && state.eliteCup.edicao;
    const eliteCupPending = !eliteCupEditionConcluded() && edicao && edicao.participantes && edicao.participantes.includes(state.userTeamId);
    const eliteCupNote = eliteCupPending
      ? `<div class="season-summary-card"><h4>⚠️ Elite Cup a caminho</h4>O ${escapeHtml(team.name)} está apurado para a Elite Cup — esta é só uma janela curta de mercado antes de a prova arrancar. Ao clicares em "Iniciar a Época" entras logo nos Quartos de Final; a época do campeonato só começa depois de a Elite Cup terminar.</div>`
      : "";
    body.innerHTML = `<div class="season-summary-grid">
      <div class="season-summary-card"><h4>Pré-época — ${escapeHtml(team.name)}</h4>
        Mercado aberto a transferências. Reforça o plantel antes da 1.ª jornada de ${competitionLabel(state.userCompetitionId)}.
      </div>
      <div class="season-summary-card"><h4>Orçamento de transferências</h4><b>${fmtMoney(team.financeiro.orcamentoTransferencias)}</b></div>
      <div class="season-summary-card"><h4>1.ª jornada</h4>${fmtDateLong(state.pendingSeasonStartDate ? addDays(state.pendingSeasonStartDate,5) : state.fixtures[0].date)}</div>
      ${eliteCupNote}
    </div>
    <div id="preSeasonPanelModal" class="hidden" style="margin-top:12px;"></div>
    <p class="helptext" style="margin-top:10px;">Vai à Central de Contratos e ao Mercado para negociar. Quando estiveres pronto, clica em "Iniciar a Época".</p>`;
    const btn=document.getElementById("defesoContinueBtn"); if(btn) btn.textContent="Iniciar a Época";
    modal.classList.remove("hidden");
    if(typeof renderPreSeasonPanel==="function") renderPreSeasonPanel();
  }
  function finalizePreSeasonDefeso(){
    // Reage a carências criadas pelo utilizador durante as negociações da pré-época (antes da
    // 1ª jornada da carreira), pela mesma razão que na transição normal de época.
    processAiToAiMarketReactive();
    state.inDefeso = false; state.isPreSeasonDefeso = false;
    expirePendingAiOffers(state.currentDate);
    const modalEl=document.getElementById("defesoModal"); if(modalEl) modalEl.classList.add("hidden");
    // Correção (pedido do utilizador): se a Elite Cup desta carreira ainda não estiver concluída,
    // esta janela de pré-época é só a curta janela ANTES da prova arrancar — currentDate não
    // avança para a 1.ª jornada do campeonato ainda, isso só acontece depois de a Elite Cup
    // terminar (ver finalizePreSeasonLeagueStart, chamada a partir de eliteCupRunPostSequence em
    // 07d-elite-cup.js quando state.eliteCupPostSequence==="preSeasonLeagueStart").
    // Correção (bug real, reportado pelo utilizador): processEliteCupForCurrentDate() já não
    // resolve nada de imediato aqui — currentDate está sempre 1 semana antes dos quartos de
    // final (ver chooseClub), por isso a chamada abaixo é, à partida, um no-op (a data ainda não
    // chegou). state.inDefeso já ficou a false (acima) — daqui em diante, cada clique em
    // "Continuar" avança um dia de cada vez pelo ciclo normal (ver o botão continuarBtn, em
    // 09-fluxo-epoca.js), que agora também verifica a Elite Cup todos os dias (ver
    // processPhaseFiveFinalsForCurrentDate, em 07-playoff.js) — só resolve mesmo quando o
    // calendário chega à data real de cada fase. É assim que dá para acompanhar a prova pelas
    // notícias, mesmo sem jogar (para quem não está apurado, tudo se resolve sozinho dia a dia).
    if(!eliteCupEditionConcluded()){
      state.eliteCupPostSequence = "preSeasonLeagueStart";
      processEliteCupForCurrentDate();
      renderHubDate();
      return;
    }
    finalizePreSeasonLeagueStart();
  }
  // Cauda da pré-época da 1.ª carreira — extraída de finalizePreSeasonDefeso para poder ser
  // adiada até a Elite Cup terminar (ver acima), tal como já acontecia para a transição normal
  // de época (finalizeNewSeasonTail, 08-evolucao-jogadores.js).
  function finalizePreSeasonLeagueStart(){
    // Correção (calendário sem saltos, pedido explícito do utilizador, 2026-09-14: "o tempo não
    // pode saltar como está a fazer agora, que salta do fim da elite cup para o campeonato"):
    // antes, esta função saltava state.currentDate diretamente para 5 dias antes da 1ª jornada,
    // ignorando por completo as semanas (normalmente ~2, agora que a Elite Cup já está no fim de
    // setembro) entre o fim da Elite Cup e outubro — sem processar nada dia a dia nesse
    // intervalo. state.currentDate fica agora onde a Elite Cup o deixou (eliteCupRunPostSequence
    // já garante que está, no mínimo, na data da final) — o clique seguinte em "Continuar" entra
    // no ciclo normal de avanço diário (ver continuarBtn, 09-fluxo-epoca.js), que já paga
    // finanças, resolve negociações e trata a Elite Cup dia a dia, chegando sozinho à 1ª jornada
    // quando o calendário lá chegar. state.pendingSeasonStartDate deixa de ser consumido aqui,
    // mas mantém-se por compatibilidade com saves antigos e para o texto informativo do ecrã de
    // pré-época (renderPreSeasonModal, acima).
    state.pendingSeasonStartDate = null;
    const continuarBtnEl=document.getElementById("continuarBtn");
    if(continuarBtnEl){ continuarBtnEl.disabled=false; continuarBtnEl.textContent="▶ Continuar"; }
    pushNews(state.currentDate, `Bem-vindo ao comando do ${teamLinkHtml(state.userTeamId)}, na ${competitionLabel(state.userCompetitionId)}! A pré-época terminou, a temporada está prestes a começar.`, "sistema");
    renderHubDate();
    setView("clube"); renderAll();
  }
  // =================================================================
  // Roster UI (user's club) — squad composition is fixed once the club is chosen;
  // only attributes/titular status can be edited (via the player card).
  // =================================================================
  const rosterBody = document.getElementById("rosterBody");
  const rosterCount = document.getElementById("rosterCount");

  function linhaAbbrev(p){
    if(p.pos==="GR") return "GR";
    if(p.linha==="DefesaMedio") return "DEF/MED";
    if(p.linha==="Avancado") return "AVÇ";
    return "—";
  }
  // Ordem de posição para listas de convocatória/escalação: GR, depois DEF/MED, depois AVÇ —
  // em vez da ordem crua do plantel, que não segue nenhum critério visual.
  function playerPositionSortKey(p){
    if(p.pos==="GR") return 0;
    if(p.linha==="DefesaMedio") return 1;
    if(p.linha==="Avancado") return 2;
    return 3;
  }
  function playerSortValue(p, key){
    if(key==="idade") return p.age||0;
    if(key==="ovr") return overall(p);
    if(key==="condicao") return p.condicao!=null?p.condicao:100;
    if(key==="satisfacao") return p.satisfacao!=null?p.satisfacao:70;
    if(key==="posicao") return p.pos==="GR" ? 0 : (p.linha==="DefesaMedio" ? 1 : 2);
    return 0;
  }
  const ROSTER_SORT_DEFAULT_DIR = { idade:"desc", posicao:"asc", ovr:"desc", condicao:"desc", satisfacao:"desc" };
  function resetRosterSort(){ state.rosterSort = { key:"posicao", dir:"asc" }; }
  resetRosterSort();

  // Separador Equipa A / Equipa B no Plantel: só visível para clubes que tenham equipa B. A
  // gestão (incluindo renovações de contrato) da equipa B cabe ao utilizador que gere o clube
  // principal — a equipa B não tem agência própria de mercado nem finanças (ver initClubFinance
  // e ensureRosterMinimumsFromFreeAgents em 04-financas.js).
  // plantelActiveTeamId(): usado para abrir a ficha de um jogador (openPlayerModal/
  // findPlayerAnywhere aceita tanto um jogador do plantel real como um jovem da Academia do
  // mesmo clube) — no modo "Formação" (state.plantelViewMode==="academia") é sempre o clube
  // principal do utilizador, nunca a equipa B (a Academia pertence sempre ao clube principal,
  // academyEligible já exclui equipas B).
  function plantelActiveTeamId(){
    if(state.plantelViewMode==="academia") return state.userTeamId;
    return state.plantelViewTeamId || state.userTeamId;
  }
  // Convocatória & 5 inicial a partir do Plantel (2026-10-03, pedido do utilizador: "No plantel
  // deve haver uma coluna antes do nome em que se pode escolher o 5 inicial e os substitutos").
  // Reaproveita tal e qual dois campos que já existiam, só nunca geridos juntos no mesmo sítio:
  // player.titular (já usado pelo motor de jogo para escolher quem começa em pista, e já editável
  // um a um na ficha do jogador) e state.convocadosSelecionados (já usado para saber quem está
  // convocado, "colado" de jogo para jogo). Esta coluna deixa de haver um ecrã de convocatória +
  // um ecrã de escalação antes de cada jogo — a configuração vive aqui, de forma persistente, e o
  // "Continuar" passa só a pedir confirmação (ver openConfirmarConvocatoriaModal, 09-fluxo-epoca.js).
  function convStatusFor(p){
    if(!state.convocadosSelecionados || !state.convocadosSelecionados[p.id]) return "nao";
    return p.titular ? "titular" : "suplente";
  }
  // Porque é que um jogador não pode ser convocado agora mesmo — suspensão e lesão já existiam;
  // ao serviço da selecção nacional é novo (2026-10-03, playerAvailableForMatch já cobria isto,
  // só faltava explicar a razão ao utilizador nesta coluna).
  function convIndisponivelMotivo(p){
    if((p.suspensoJogos||0)>0) return "Suspenso";
    if((p.diasLesao||0)>0) return "Lesionado";
    if(p.convocadoSelecaoAte && state.currentDate<=p.convocadoSelecaoAte) return "Ao serviço da selecção nacional";
    return null;
  }
  // Primeira vez (sem nenhuma configuração ainda): sugere os melhores por omissão, tal como o
  // antigo ecrã de convocatória já fazia. Nas vezes seguintes, só corrige inconsistências — nunca
  // escolhe por omissão no lugar do utilizador (esse é agora o papel desta coluna, não de um
  // ecrã pré-jogo): um jogador que deixou de estar disponível (suspensão/lesão/selecção nacional)
  // é sempre removido da convocatória e do lugar de titular; um jogador marcado titular por outra
  // via (ex.: a ficha do jogador) fica sempre implicitamente convocado também.
  function ensureSquadSelectionDefaults(){
    const club = myTeam();
    if(!club) return;
    if(!state.convocadosSelecionados){
      state.convocadosSelecionados = {};
      const grs = club.players.filter(p=>p.pos==="GR" && playerAvailableForMatch(p)).sort((a,b)=>overall(b)-overall(a));
      const js = club.players.filter(p=>p.pos==="J" && playerAvailableForMatch(p)).sort((a,b)=>overall(b)-overall(a));
      const grConv = grs.slice(0,CONVOCATORIA_MAX_GR), jConv = js.slice(0,CONVOCATORIA_MAX_J);
      const convIds = new Set([...grConv, ...jConv].map(p=>p.id));
      club.players.forEach(p=>{ state.convocadosSelecionados[p.id] = convIds.has(p.id); p.titular = false; });
      if(grConv[0]) grConv[0].titular = true;
      jConv.slice(0,4).forEach(p=>{ p.titular = true; });
      return;
    }
    club.players.forEach(p=>{
      if(state.convocadosSelecionados[p.id]===undefined) state.convocadosSelecionados[p.id] = false;
      if(!playerAvailableForMatch(p)){
        if(state.convocadosSelecionados[p.id] || p.titular){ state.convocadosSelecionados[p.id] = false; p.titular = false; }
      } else if(p.titular){
        state.convocadosSelecionados[p.id] = true; // titular implica sempre convocado
      }
    });
  }
  // Se marcar `target` violaria algum dos tectos (2 GR / 8 J convocados, 1 GR / 4 J titulares) —
  // usado para desativar essa opção no <select> da coluna nova, mesmo padrão de "capReached" já
  // usado no antigo ecrã de convocatória.
  function convOptionAllowed(p, target, counts){
    const current = convStatusFor(p);
    if(current===target) return true;
    const isGR = p.pos==="GR";
    const maxConv = isGR ? CONVOCATORIA_MAX_GR : CONVOCATORIA_MAX_J;
    const maxTit = isGR ? 1 : 4;
    const deltaConv = (target!=="nao"?1:0) - (current!=="nao"?1:0);
    const deltaTit = (target==="titular"?1:0) - (current==="titular"?1:0);
    const newConv = (isGR?counts.convGR:counts.convJ) + deltaConv;
    const newTit = (isGR?counts.titGR:counts.titJ) + deltaTit;
    return newConv<=maxConv && newTit<=maxTit;
  }
  function convStatusHtml(p, counts){
    const motivo = convIndisponivelMotivo(p);
    if(motivo) return `<select class="conv-status-select" disabled title="Indisponível: ${escapeHtml(motivo)}"><option>—</option></select>`;
    const status = convStatusFor(p);
    const opt = (value,label) => {
      const selected = status===value ? " selected" : "";
      const disabled = (status!==value && !convOptionAllowed(p,value,counts)) ? " disabled" : "";
      return `<option value="${value}"${selected}${disabled}>${label}</option>`;
    };
    return `<select class="conv-status-select conv-status-${status}" data-id="${p.id}" title="Estado na próxima convocatória">
      ${opt("nao","—")}${opt("suplente","Suplente")}${opt("titular","Titular")}
    </select>`;
  }

  function renderRoster(){
    const mine = myTeam();
    if(!mine) return;
    const hasAcademy = academyEligible(mine) && !!mine.academy;
    const switchEl = document.getElementById("plantelTeamSwitch");
    if(switchEl){
      const hasB = !!(mine.equipaBId && state.teams[mine.equipaBId]);
      switchEl.classList.toggle("hidden", !hasB && !hasAcademy);
      if(!hasB && state.plantelViewMode!=="academia") state.plantelViewTeamId = null;
      const formacaoBtn = document.getElementById("plantelFormacaoBtn");
      if(formacaoBtn) formacaoBtn.classList.toggle("hidden", !hasAcademy);
      switchEl.querySelectorAll("[data-plantel-team='A'],[data-plantel-team='B']").forEach(btn=>{
        btn.classList.toggle("hidden", !hasB);
      });
      switchEl.querySelectorAll("[data-plantel-team]").forEach(btn=>{
        const mode = btn.getAttribute("data-plantel-team");
        const isActive = mode==="academia" ? state.plantelViewMode==="academia"
          : state.plantelViewMode!=="academia" && (mode==="A" ? plantelActiveTeamId()===mine.id : plantelActiveTeamId()===mine.equipaBId);
        btn.classList.toggle("active", isActive);
      });
    }
    const numHeader = document.getElementById("rosterNumHeader");
    const filtroLabel = document.getElementById("plantelFiltroLabel");
    if(state.plantelViewMode==="academia"){
      if(numHeader) numHeader.textContent = "Escalão";
      if(filtroLabel) filtroLabel.textContent = "Filtro: Formação (sem salário, sem jogos oficiais)";
      renderAcademiaRoster(mine);
      renderBalnearioPanel();
      return;
    }
    if(numHeader) numHeader.textContent = "Nº";
    if(filtroLabel) filtroLabel.textContent = "Filtro: Plantel principal";
    const club = state.teams[plantelActiveTeamId()] || mine;
    // Coluna de convocatória/5 inicial: só faz sentido na própria equipa principal — a equipa B
    // nunca é convocada para os jogos da equipa A (ver ensureSquadSelectionDefaults/openConfirmarConvocatoriaModal).
    const isMainTeamView = club.id === mine.id;
    if(isMainTeamView) ensureSquadSelectionDefaults();
    const convCounts = isMainTeamView ? {
      convGR: club.players.filter(p=>p.pos==="GR" && state.convocadosSelecionados[p.id]).length,
      convJ: club.players.filter(p=>p.pos!=="GR" && state.convocadosSelecionados[p.id]).length,
      titGR: club.players.filter(p=>p.pos==="GR" && p.titular && state.convocadosSelecionados[p.id]).length,
      titJ: club.players.filter(p=>p.pos!=="GR" && p.titular && state.convocadosSelecionados[p.id]).length,
    } : null;
    if(!state.rosterSort) resetRosterSort();
    const { key, dir } = state.rosterSort;
    // Jogadores cedidos a outros clubes continuam na lista do clube dono (mesmo objeto, mesmo ID).
    const cedidosFora = empEmprestadosFora(club.id);
    const cedidoDest = {}; cedidosFora.forEach(x=>{ cedidoDest[x.p.id] = x.dest; });
    const sortedPlayers = club.players.concat(cedidosFora.map(x=>x.p)).sort((a,b)=>{
      const va = playerSortValue(a,key), vb = playerSortValue(b,key);
      const cmp = va - vb;
      return dir==="asc" ? cmp : -cmp;
    });
    document.querySelectorAll("#viewPlantel .sortable-col").forEach(th=>{
      const k = th.getAttribute("data-sort");
      th.classList.toggle("sorted", k===key);
      th.setAttribute("data-dir", k===key ? dir : "");
    });
    rosterBody.innerHTML = "";
    sortedPlayers.forEach((p) => {
      const tr = document.createElement("tr");
      const condVal = p.condicao!=null ? p.condicao : 100;
      const cond = Math.round(condVal);
      const satVal = p.satisfacao!=null ? p.satisfacao : 70;
      const cedidoA = cedidoDest[p.id] || null;
      if(cedidoA) tr.className = "roster-cedido";
      const estatutoEfetivo = cedidoA ? "" : effectivePlayerEstatuto(p, club);
      const estatutoBadge = estatutoEfetivo==="Indispensável" ? ` <span class="roster-badge roster-badge-indispensavel" title="Estatuto: Indispensável">★</span>` : estatutoEfetivo==="Titular importante" ? ` <span class="roster-badge roster-badge-titular" title="Estatuto: Titular importante">☆</span>` : '';
      tr.innerHTML = `
        <td class="num-col">${p.num}</td>
        <td class="conv-status-col">${isMainTeamView && !cedidoA ? convStatusHtml(p, convCounts) : ''}</td>
        <td>${nationalityFlagHtml(p)} <button class="playername-btn" data-id="${p.id}">${playerNameHtml(p, cedidoA ? {cedido:true} : undefined)}</button>${cedidoA ? ` <span class="roster-cedido-dest" title="Só pode jogar no clube que o recebeu">→ ${escapeHtml(cedidoA.name)}</span>` : ''}${estatutoBadge}${isMainTeamView && !cedidoA && balnearioIsCaptain(club,p) ? ' <span class="roster-badge roster-badge-capitao" title="Capitão">C</span>' : ''}${p.transferListado?` <span class="roster-badge roster-badge-tag" title="No mercado por ${fmtMoney(p.valorPedido)}">🏷️</span>`:''}${p.pendingTransferHold?` <span class="roster-badge roster-badge-trf" title="${escapeHtml(contractStatusLabel(p))}">🏷️TRF</span>`:''}</td>
        <td class="num-col">${p.age}</td>
        <td class="pos-col"><span class="pos-badge ${p.pos==='GR'?'gr':'j'}">${linhaAbbrev(p)}</span></td>
        <td class="ovr-col">${evolutionArrowHtml(p,"ovr")}${overall(p)}</td>
        <td class="cond-col"><div class="fit-bar-bg" title="Condição física: ${condVal.toFixed(1)}%"><div class="fit-bar-fill" style="width:${cond}%;background:${fitnessColor(cond)};"></div></div></td>
        <td class="cond-col"><div class="fit-bar-bg" title="Satisfação: ${satVal.toFixed(1)}"><div class="fit-bar-fill" style="width:${Math.round(satVal)}%;background:${fitnessColor(Math.round(satVal))};"></div></div></td>
        <td class="star-col">${(p.suspensoJogos||0)>0?'<span title="Suspenso" style="color:var(--vermelho);font-weight:900;">🚫</span>':(p.diasLesao||0)>0?`<span title="${escapeHtml(lesTituloRoster(p))}" style="color:var(--vermelho);font-weight:900;">🚑</span>`:(p.readapt?`<span title="${escapeHtml(lesTituloReadapt(p))}" style="font-weight:900;">🩹</span>`:(p.titular&&!cedidoA?'⭐':''))}${club.id===state.userTeamId&&!cedidoA?cargaBadgeHtml(p):''}</td>
      `;
      rosterBody.appendChild(tr);
    });
    const gr = club.players.filter(p=>p.pos==="GR").length;
    const j = club.players.length - gr;
    rosterCount.textContent = `${club.players.length} jogadores · ${gr} GR / ${j} jog.${cedidosFora.length ? ` · ${cedidosFora.length} cedido${cedidosFora.length>1?'s':''}` : ''}`;
    renderBalnearioPanel();
  }
  // Vista "Formação" do separador Plantel (pedido do utilizador: "a formação tem de aparecer no
  // separador plantel"), a par das já existentes Equipa A / Equipa B — reaproveita a mesma tabela
  // do plantel (não uma tabela nova), só com colunas adaptadas: a coluna "Nº" mostra o escalão
  // (Sub-13/15/17/19) em vez do número de camisola (irrelevante antes da promoção), e não há
  // estatuto/mercado/lesão/suspensão (mecânicas que só existem para jogadores em competição). É
  // sempre o clube principal do utilizador (a Academia nunca pertence à equipa B). Overall exacto
  // (sem ruído de informação imperfeita) — é sempre o próprio clube do utilizador a ver a sua
  // própria Academia, nunca a de um adversário.
  function renderAcademiaRoster(mine){
    if(!state.rosterSort) resetRosterSort();
    const { key, dir } = state.rosterSort;
    document.querySelectorAll("#viewPlantel .sortable-col").forEach(th=>{
      const k = th.getAttribute("data-sort");
      th.classList.toggle("sorted", k===key);
      th.setAttribute("data-dir", k===key ? dir : "");
    });
    rosterBody.innerHTML = "";
    const allAcademyPlayers = ACADEMY_BRACKETS.flatMap(b => mine.academy.brackets[b].players);
    if(!allAcademyPlayers.length){
      rosterBody.innerHTML = `<tr><td colspan="9" style="text-align:center;color:var(--texto-mute);padding:16px;">Sem jogadores na Academia.</td></tr>`;
    }
    // Pedido do utilizador (2026-09-23): "separa os escalões" — em vez de uma única lista com
    // Sub-13 a Sub-19 misturados (só distinguíveis pela etiqueta na 1ª coluna), agrupa por
    // escalão (ordem Sub-13→Sub-19 de ACADEMY_BRACKETS), com uma linha de cabeçalho de secção
    // antes de cada grupo (mesma classe pm-retro-section-lbl já usada no separador Academia da
    // Ficha do Clube) — a ordenação escolhida pelo utilizador (clicar no cabeçalho da coluna)
    // continua a aplicar-se dentro de cada grupo, não ao conjunto todo.
    ACADEMY_BRACKETS.forEach(bracket => {
      const players = mine.academy.brackets[bracket].players;
      if(!players.length) return;
      const headerTr = document.createElement("tr");
      headerTr.innerHTML = `<td colspan="9" class="pm-retro-section-lbl" style="padding:6px 8px;">${ACADEMY_BRACKET_LABEL[bracket]} (${players.length})</td>`;
      rosterBody.appendChild(headerTr);
      const sortedPlayers = players.slice().sort((a,b)=>{
        const va = playerSortValue(a,key), vb = playerSortValue(b,key);
        const cmp = va - vb;
        return dir==="asc" ? cmp : -cmp;
      });
      sortedPlayers.forEach(p => {
        const tr = document.createElement("tr");
        const condVal = p.condicao!=null ? p.condicao : 100;
        const cond = Math.round(condVal);
        const satVal = p.satisfacao!=null ? p.satisfacao : 70;
        tr.innerHTML = `
          <td class="num-col">${ACADEMY_BRACKET_LABEL[bracket]}</td>
          <td class="conv-status-col"></td>
          <td><button class="playername-btn" data-id="${p.id}">${playerNameHtml(p)}</button></td>
          <td class="num-col">${p.age}</td>
          <td class="pos-col"><span class="pos-badge ${p.pos==='GR'?'gr':'j'}">${linhaAbbrev(p)}</span></td>
          <td class="ovr-col">${evolutionArrowHtml(p,"ovr")}${overall(p)}</td>
          <td class="cond-col"><div class="fit-bar-bg" title="Condição física: ${condVal.toFixed(1)}%"><div class="fit-bar-fill" style="width:${cond}%;background:${fitnessColor(cond)};"></div></div></td>
          <td class="cond-col"><div class="fit-bar-bg" title="Satisfação: ${satVal.toFixed(1)}"><div class="fit-bar-fill" style="width:${Math.round(satVal)}%;background:${fitnessColor(Math.round(satVal))};"></div></div></td>
          <td class="star-col"></td>
        `;
        rosterBody.appendChild(tr);
      });
    });
    const gr = allAcademyPlayers.filter(p=>p.pos==="GR").length;
    const j = allAcademyPlayers.length - gr;
    rosterCount.textContent = `${allAcademyPlayers.length} jogadores na Academia · ${gr} GR / ${j} jog.`;
  }

  document.querySelectorAll("#viewPlantel .sortable-col").forEach(th=>{
    th.addEventListener("click", () => {
      const k = th.getAttribute("data-sort");
      if(!state.rosterSort) resetRosterSort();
      if(state.rosterSort.key === k){
        state.rosterSort.dir = state.rosterSort.dir==="asc" ? "desc" : "asc";
      } else {
        state.rosterSort = { key:k, dir: ROSTER_SORT_DEFAULT_DIR[k] || "desc" };
      }
      renderRoster();
    });
  });

  rosterBody.addEventListener("click", (e) => {
    const btn = e.target.closest(".playername-btn");
    if(btn){
      openPlayerModal(plantelActiveTeamId(), btn.getAttribute("data-id"));
    }
  });
  // Convocatória & 5 inicial a partir do Plantel (2026-10-03) — ver convStatusHtml/convOptionAllowed
  // acima. GR: só pode haver 1 titular — marcar um novo despromove automaticamente o anterior a
  // suplente (nunca os dois titulares ao mesmo tempo); jogadores de campo não têm despromoção
  // automática, o tecto de 4 já impede escolher um 5º (opção desativada no <select>).
  rosterBody.addEventListener("change", (e) => {
    const sel = e.target.closest(".conv-status-select");
    if(!sel || !sel.dataset.id) return;
    const club = myTeam(); if(!club) return;
    const p = club.players.find(pl=>pl.id===sel.dataset.id);
    if(!p) return;
    const novoEstado = sel.value;
    if(novoEstado==="nao"){
      state.convocadosSelecionados[p.id] = false; p.titular = false;
    } else if(novoEstado==="suplente"){
      state.convocadosSelecionados[p.id] = true; p.titular = false;
    } else if(novoEstado==="titular"){
      if(p.pos==="GR") club.players.forEach(o=>{ if(o.pos==="GR" && o.id!==p.id) o.titular = false; });
      state.convocadosSelecionados[p.id] = true; p.titular = true;
    }
    renderRoster();
  });
  document.getElementById("plantelTeamSwitch")?.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-plantel-team]");
    if(!btn) return;
    const mine = myTeam(); if(!mine) return;
    const mode = btn.getAttribute("data-plantel-team");
    if(mode==="academia"){
      state.plantelViewMode = "academia";
    } else {
      state.plantelViewMode = null;
      state.plantelViewTeamId = mode==="A" ? mine.id : mine.equipaBId;
    }
    renderRoster();
  });

  // Fase A: um único listener delegado trata Sistema/Mentalidade/Pressão em qualquer sítio onde
  // apareçam (separador Táticas, painel ao vivo) — setTeamSistema/setTeamMentalidade/setTeamPressao
  // (01-nucleo.js) já tratam de sincronizar as duas cópias visuais entre si.
  document.body.addEventListener("click", (e) => {
    const sistemaBtn = e.target.closest(".tactic-row [data-sistema]");
    if(sistemaBtn){ setTeamSistema(sistemaBtn.getAttribute("data-sistema")); return; }
    const mentalidadeBtn = e.target.closest(".tactic-row [data-mentalidade]");
    if(mentalidadeBtn){ setTeamMentalidade(mentalidadeBtn.getAttribute("data-mentalidade")); return; }
    const pressaoBtn = e.target.closest(".tactic-row [data-pressao]");
    if(pressaoBtn){ setTeamPressao(pressaoBtn.getAttribute("data-pressao")); return; }
    const treinoBtn = e.target.closest(".tactic-row [data-treino]");
    if(treinoBtn){ setTeamTreino(treinoBtn.getAttribute("data-treino")); }
  });

  // =================================================================
  // Import plantel modal
  // =================================================================
  const importModal = document.getElementById("importModal");
  const importTextarea = document.getElementById("importTextarea");
  const importErr = document.getElementById("importErr");

  function openImportModal(teamId){
    state.importTargetId = teamId;
    document.getElementById("importModalTitle").textContent = "Importar plantel — " + state.teams[teamId].name;
    importTextarea.value = ""; importErr.textContent = "";
    importModal.classList.remove("hidden");
  }
  document.getElementById("importCancelBtn").addEventListener("click", () => importModal.classList.add("hidden"));

  function slugify(str){
    return String(str||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"") || "jogador";
  }
  // Fábrica única de estatísticas — usada por todos os caminhos de criação de jogador
  // (gerado, importado, provisório) para garantir que a estrutura é sempre idêntica.
  function createEmptyStats(kind){
    const base = {
      jogos:0, jogosTitular:0, jogosSuplente:0, golos:0, assistencias:0,
      amarelos:0, azuis:0, vermelhos:0, mvp:0, golosSofridos:0,
    };
    if(kind==="season") return { ...base, notas:[],
      penaltisMarcados:0, penaltisFalhados:0, penaltisTentados:0, penaltisDefendidos:0, penaltisSofridos:0,
      livresDiretosMarcados:0, livresDiretosFalhados:0, livresDiretosTentados:0, livresDiretosDefendidos:0, livresDiretosSofridos:0 };
    return base;
  }

  function normalizeImportedPlayer(raw, idx, teamId, usedIds, usedNums, divisao, pais){
    usedIds = usedIds || new Set();
    usedNums = usedNums || new Set();
    const pos = raw.pos==="GR" ? "GR" : "J";
    const nivel = clampAttr(parseInt(raw.nivel,10) != null && !isNaN(parseInt(raw.nivel,10)) ? raw.nivel : 13);
    const ra = raw.attrs && typeof raw.attrs==="object" ? raw.attrs : {};
    // ID permanente: usa o que vier da base de dados; senão gera a partir do nome (nunca da
    // posição no array, para não mudar se o plantel for reordenado ou editado). Em caso de
    // colisão (nomes iguais no mesmo plantel), acrescenta um sufixo estável.
    let stableId = raw.id ? String(raw.id).slice(0,80) : (teamId+"-"+slugify(raw.name));
    if(usedIds.has(stableId)){
      let n = 2;
      while(usedIds.has(stableId+"-"+n)) n++;
      stableId = stableId+"-"+n;
    }
    usedIds.add(stableId);
    const rng = makeSeededRng(stableId+"|"+String((raw.name||"Jogador")).trim());
    // Linha (Avançado / Defesa-Médio): usa a que vier da base de dados (aceita variantes com/sem
    // acento), senão sorteia de forma determinística — só se aplica a jogadores de campo.
    let linha = null;
    if(pos==="J"){
      const rawLinha = String(raw.linha||"").toLowerCase();
      if(rawLinha.includes("avan")) linha = "Avancado";
      else if(rawLinha.includes("defesa") || rawLinha.includes("médio") || rawLinha.includes("medio")) linha = "DefesaMedio";
      else linha = seededRnd(rng,0,1)===0 ? "Avancado" : "DefesaMedio";
    }
    const explicitAttrKeys = {};
    const pick = (key, fallback) => {
      if(ra[key]!=null){ explicitAttrKeys[key]=true; return clampAttr(ra[key]); }
      return clampAttr(fallback!=null ? fallback : nivel+seededRnd(rng,-2,2));
    };
    let attrs;
    if(pos==="GR"){
      attrs = {
        reflexos: pick("reflexos"), umParaUm: pick("umParaUm"), agilidade: pick("agilidade"),
        concentracao: pick("concentracao"), meiaDistancia: pick("meiaDistancia"), forca: pick("forca"),
        agressividade: pick("agressividade", seededRnd(rng,4,16)), determinacao: pick("determinacao", seededRnd(rng,6,17)),
        lideranca: pick("lideranca", seededRnd(rng,4,16)), resistencia: pick("resistencia"),
      };
    } else {
      attrs = {
        habilidade: pick("habilidade"), drible: pick("drible"), criatividade: pick("criatividade"),
        finalizacao: pick("finalizacao"), bolasParadas: pick("bolasParadas"), meiaDistancia: pick("meiaDistancia"), posicionamento: pick("posicionamento"), desarme: pick("desarme"),
        forca: pick("forca"), velocidade: pick("velocidade"), aceleracao: pick("aceleracao"),
        agressividade: pick("agressividade", seededRnd(rng,4,16)), determinacao: pick("determinacao", seededRnd(rng,6,17)),
        lideranca: pick("lideranca", seededRnd(rng,4,16)), resistencia: pick("resistencia"),
      };
      // o viés de linha (Avançado/Defesa-Médio) só se aplica a atributos que foram gerados
      // automaticamente — nunca aos que já vinham explícitos na base de dados, que são a
      // verdadeira fonte da verdade e devem entrar em jogo exatamente como estão.
      const biased = applyLinhaBias({ ...attrs }, linha);
      Object.keys(attrs).forEach(k => { if(!explicitAttrKeys[k]) attrs[k] = biased[k]; });
    }
    // Data de nascimento: usa a real se vier na base de dados; senão sintetiza uma coerente
    // com a idade conhecida; se não soubermos rigorosamente nada, cai em 01/01/1990. A partir
    // daqui, dataNascimento é a única fonte da idade — nunca se guarda "idade" em paralelo.
    let dataNascimento;
    if(raw.dataNascimento){
      dataNascimento = String(raw.dataNascimento).slice(0,10);
    } else if(raw.idade){
      dataNascimento = makeBirthDate(rng, clamp(parseInt(raw.idade,10),16,42));
    } else {
      dataNascimento = "1990-01-01";
    }
    const age = computeAge(dataNascimento, (state.currentDate||REFERENCE_AGE_DATE)) ?? seededRnd(rng,19,33);
    const ovr = overallFromAttrs(pos, attrs);
    const potential = raw.potencial!=null ? clampAttr(raw.potencial) : (age<=23 ? clampAttr(ovr+seededRnd(rng,1,3)) : clampAttr(ovr+seededRnd(rng,0,1)));
    const temperamento = TEMPERAMENTS.includes(raw.temperamento) ? raw.temperamento : TEMPERAMENTS[seededRnd(rng,0,TEMPERAMENTS.length-1)];
    let historico = [];
    if(Array.isArray(raw.historico)){
      historico = raw.historico.map(h => ({
        epoca: String(h.epoca||"—").slice(0,12),
        clube: String(h.clube||"—").slice(0,40),
        jogos: parseInt(h.jogos,10)||0,
        golos: parseInt(h.golos,10)||0,
        assistencias: parseInt(h.assistencias,10)||0,
      }));
    }
    const titulos = Array.isArray(raw.titulos) ? raw.titulos.map(t=>String(t).slice(0,60)) : [];
    const internacionalizacoes = parseInt(raw.internacionalizacoes,10) || 0;
    const golosInternacional = parseInt(raw.golosInternacional,10) || 0;
    let num = clamp(parseInt(raw.num,10)||(idx+1), 1, 99);
    if(usedNums.has(num)){
      let n = 1;
      while(usedNums.has(n) && n<=99) n++;
      num = n;
    }
    usedNums.add(num);
    return {
      id: stableId,
      num,
      name: String(raw.name||"Jogador").trim().slice(0,40),
      // Correção (Serie A1, 2026-09-06): esta função servia planteis importados (Builder externo
      // ou o próprio modal "Importar plantel" do jogo) e atribuía sempre "pt"/"Portuguesa" a
      // qualquer jogador, mesmo num clube da OK Liga ou da Serie A1 — inofensivo enquanto só havia
      // planteis reais portugueses, mas quebraria por completo o prémio de deslocação/custo de
      // alojamento no dia em que se importe um plantel real espanhol ou italiano. Deriva-se agora
      // do país do clube de destino (novo parâmetro `pais`), tal como generatePlaceholderRoster já
      // faz — só cai em "pt" quando o país não é indicado (planteis antigos, sem esta informação).
      pos, linha, age, dataNascimento,
      nacionalidade: raw.nacionalidade ? String(raw.nacionalidade).slice(0,30) : nationalityForCountry(pais),
      paisOrigem: raw.paisOrigem ? normalizeCountryCode(String(raw.paisOrigem)) : normalizeCountryCode(pais),
      attrs, potential, temperamento,
      contrato: raw.contrato && typeof raw.contrato==="object"
        ? generateContract(ovr, age, {
            rng, potential, divisao,
            salarioMensal: parseInt(raw.contrato.salarioMensal,10) || undefined,
            anos: raw.contrato.anos!=null ? clamp(parseInt(raw.contrato.anos,10)||1, 1, 6) : undefined,
            dataInicio: raw.contrato.dataInicio || undefined,
            papel: PLAYER_ROLES.includes(raw.contrato.papel) ? raw.contrato.papel : undefined,
          })
        : generateContract(ovr, age, { rng, potential, divisao }),
      preContrato: null,
      moral: seededRnd(rng,55,80), satisfacao: seededRnd(rng,55,80), reputacaoJogador: 0,
      titular:false, suspensoJogos:0, diasLesao:0, condicao:100,
      season:createEmptyStats("season"),
      career:createEmptyStats("career"),
      historico, titulos, internacionalizacoes, golosInternacional,
    };
  }

  document.getElementById("importSaveBtn").addEventListener("click", () => {
    try{
      const data = JSON.parse(importTextarea.value);
      if(!Array.isArray(data) || data.length===0) throw new Error("Tem de ser uma lista (array) de jogadores.");
      const importUsedIds = new Set(), importUsedNums = new Set();
      const importTargetTeam = state.teams[state.importTargetId];
      const cleaned = data.map((p,idx) => normalizeImportedPlayer(p, idx, state.importTargetId, importUsedIds, importUsedNums, importTargetTeam&&importTargetTeam.divisaoAtual, importTargetTeam&&teamCountry(importTargetTeam)));
      if(cleaned.filter(p=>p.pos==="GR").length < 1) throw new Error("O plantel precisa de pelo menos 1 guarda-redes (Art.2).");
      state.teams[state.importTargetId].players = cleaned;
      state.teams[state.importTargetId].provisional = false;
      importModal.classList.add("hidden");
      renderAll();
    }catch(err){ importErr.textContent = "Erro: " + err.message; }
  });

  // =================================================================
  // Treinador/gestor detail modal (Staff — Fase 3, 2026-09-22)
  // =================================================================
  // Ficha do staff, visualmente idêntica à do jogador (mesmas classes .pm-retro-*, 3 separadores
  // Perfil/Pessoal/Histórico) — pedido explícito do utilizador. Modal próprio (não reaproveita
  // playerModal/pmActiveTab, que estão amarrados a estado específico de jogador — ficheiro-
  // histórico, negociação de contrato, etc.). Serve tanto um treinador de um clube da IA como o
  // próprio gestor humano (activeCoachingStats/treinadorFichaData, 08c-staff-treinadores.js) —
  // os dois abrem exactamente o mesmo componente.
  const treinadorModal = document.getElementById("treinadorModal");
  const treinadorModalBox = document.getElementById("treinadorModalBox");
  let tmActiveTab = "perfil";
  function treinadorStatRowHtml(stats, key) {
    const v = stats && stats[key] != null ? Math.round(stats[key]) : 10;
    return `<div class="pm-retro-row"><span class="lbl">${escapeHtml(TREINADOR_STAT_LABEL[key] || key)}</span><span class="val" style="color:${attrValColor(v)};">${v}</span></div>`;
  }
  function openTreinadorModal(kind, teamId, tab) {
    playerModal.classList.add("hidden");
    tmActiveTab = tab || "perfil";
    renderTreinadorModalContent(kind, teamId, tmActiveTab);
  }
  function renderTreinadorModalContent(kind, teamId, tab) {
    const data = treinadorFichaData(kind, teamId);
    if (!data) return;
    tmActiveTab = tab || tmActiveTab;
    const m = data.mandatoAtual;
    const pct = treinadorRecordPct(m);

    const perfilHtml = `
      <div class="pm-retro-subline"><b>${escapeHtml(data.nome)}</b> — ${escapeHtml(data.clubeNome)}</div>
      <div class="pm-retro-cols">
        <div>
          <div class="pm-retro-section-lbl">Competência</div>
          ${TREINADOR_STATS_COMPETENCIA.map(k => treinadorStatRowHtml(data.stats, k)).join("")}
        </div>
        <div>
          <div class="pm-retro-section-lbl">Perfil</div>
          ${TREINADOR_STATS_PERFIL.map(k => treinadorStatRowHtml(data.stats, k)).join("")}
        </div>
      </div>
      <div class="pm-retro-section-lbl">Mandato atual</div>
      <table class="pm-retro-stat-table">
        <thead><tr><th>J</th><th>V</th><th>E</th><th>D</th><th>%V</th></tr></thead>
        <tbody><tr><td>${m.jogos}</td><td>${m.vitorias}</td><td>${m.empates}</td><td>${m.derrotas}</td><td>${pct}%</td></tr></tbody>
      </table>
    `;

    const pessoalHtml = `
      <div class="pm-retro-row"><span class="lbl">Data de Nascimento</span><span class="val">${fmtDateShort(data.dataNascimento)}</span></div>
      <div class="pm-retro-row"><span class="lbl">Nacionalidade</span><span class="val">${escapeHtml(data.nacionalidade || "Portuguesa")}</span></div>
      <div class="pm-retro-row"><span class="lbl">Clube atual</span><span class="val">${escapeHtml(data.clubeNome)}</span></div>
      <div class="pm-retro-row"><span class="lbl">Início do mandato</span><span class="val">${fmtDateShort(m.dataInicio)}</span></div>
      ${data.salario!=null?`<div class="pm-retro-row"><span class="lbl">Salário mensal</span><span class="val">${fmtMoney(data.salario)}</span></div>`:''}
    `;

    const currentRow = { epoca: seasonLabel(state.season), clube: data.clubeNome, jogos: m.jogos, vitorias: m.vitorias, empates: m.empates, derrotas: m.derrotas, emCurso: true };
    const historicalRows = (data.historico || []).map(h => ({ epoca: h.epocaSaida, clube: h.clubName, jogos: h.jogos, vitorias: h.vitorias, empates: h.empates, derrotas: h.derrotas }));
    const rows = historicalRows.concat([currentRow]);
    const historicoHtml = `
      <table class="pm-retro-stat-table" style="text-align:left;">
        <thead><tr><th style="text-align:left;">Época</th><th style="text-align:left;">Clube</th><th>J</th><th>V</th><th>E</th><th>D</th><th>%V</th></tr></thead>
        <tbody>
          ${rows.map(h => `<tr><td style="text-align:left;">${escapeHtml(String(h.epoca || "—"))}${h.emCurso ? ' <span class="helptext">(actual)</span>' : ''}</td><td style="text-align:left;">${escapeHtml(h.clube || "—")}</td><td>${h.jogos}</td><td>${h.vitorias}</td><td>${h.empates}</td><td>${h.derrotas}</td><td>${treinadorRecordPct(h)}%</td></tr>`).join("")}
        </tbody>
      </table>
      <p class="pm-retro-subline" style="margin-top:6px;">%V: percentagem de vitórias na época.</p>
    `;

    treinadorModalBox.style.maxWidth = "700px";
    treinadorModalBox.style.padding = "20px";
    treinadorModalBox.innerHTML = `
      <div class="pm-retro">
        <div class="pm-retro-titlebar">
          <span class="ttl">${escapeHtml(data.nome)} <span style="font-weight:400;color:var(--texto-mute);font-size:11px;">(${escapeHtml(data.clubeNome)})</span></span>
        </div>
        <div class="pm-retro-tabs">
          <div class="pm-retro-tab ${tmActiveTab === 'perfil' ? 'active' : ''}" data-tab="perfil">Perfil</div>
          <div class="pm-retro-tab ${tmActiveTab === 'pessoal' ? 'active' : ''}" data-tab="pessoal">Pessoal</div>
          <div class="pm-retro-tab ${tmActiveTab === 'historico' ? 'active' : ''}" data-tab="historico">Histórico</div>
        </div>
        <div class="pm-retro-body">${tmActiveTab === 'perfil' ? perfilHtml : tmActiveTab === 'pessoal' ? pessoalHtml : historicoHtml}</div>
        <div class="pm-retro-actions">
          <button id="tmCloseBtn">Fechar</button>
        </div>
      </div>
    `;
    treinadorModal.classList.remove("hidden");
    document.getElementById("tmCloseBtn").addEventListener("click", () => { treinadorModal.classList.add("hidden"); });
    treinadorModalBox.querySelectorAll(".pm-retro-tab").forEach(t => {
      t.addEventListener("click", () => renderTreinadorModalContent(kind, teamId, t.getAttribute("data-tab")));
    });
  }

  // =================================================================
  // Modal da Seleção Nacional (2026-09-27, pedido do utilizador: "as seleções têm de ser
  // clicáveis e tem de aparecer a lista dos jogadores da última convocatória") — mesmo padrão
  // simples do modal do treinador (um único corpo, sem separadores nem histórico de navegação):
  // qualquer bandeira/nome de seleção clicável em toda a interface (classificação, calendário,
  // histórico, notícias) tem data-selecao="<code>" e abre este modal, que lê exclusivamente de
  // state.selecoesUltimaConvocatoria (as equipas virtuais já não existem entre torneios) — nunca
  // muda sozinho, só é reescrito quando essa seleção volta a ser convocada (ver
  // resolveSelecaoTournament, 07h-selecoes.js).
  const selecaoModal = document.getElementById("selecaoModal");
  const selecaoModalBox = document.getElementById("selecaoModalBox");
  function openSelecaoModal(code){
    const nation = SELECAO_NATIONS[code];
    if(!nation) return;
    // Mesmo cuidado de openTreinadorModal (esconde playerModal ao abrir) — evita dois modais
    // sobrepostos caso este seja aberto a partir de outro já visível.
    playerModal.classList.add("hidden");
    const conv = state.selecoesUltimaConvocatoria && state.selecoesUltimaConvocatoria[code];
    const jogadorRowHtml = j => {
      const nomeHtml = j.teamId ? playerLinkHtml(j.teamId, findPlayerAnywhere(j.teamId, j.id) || {id:j.id, name:j.nome})
        : `<span style="color:var(--texto-mute);">${escapeHtml(j.nome)}</span>`;
      const clubeHtml = j.filler
        ? `<span class="helptext">gerado para a seleção — sem clube</span>`
        : (j.teamId && state.teams[j.teamId] ? escapeHtml(state.teams[j.teamId].name) : `<span class="helptext">clube desconhecido</span>`);
      return `<div class="fixture-row" style="grid-template-columns:26px minmax(0,180px) 1fr;font-size:14px;">
        <div>${j.pos==="GR"?"🧤":""}</div>
        <div>${nomeHtml}</div>
        <div style="color:var(--texto-mute);font-size:12px;">${clubeHtml}</div>
      </div>`;
    };
    // Emblemas (pedido do utilizador, 2026-10-02: "símbolos das federações... da federação
    // internacional nos mundiais, da europeia no europeu"): o emblema da prova (World Skate no
    // Mundial, World Skate Europe no Europeu — competitionLogoUrl, 01-nucleo.js) aparece junto da
    // linha "Última convocatória"; o da FPP (federationLogoUrl) aparece junto da bandeira, só na
    // Seleção de Portugal (é a única federação nacional dentro do âmbito pedido — as restantes
    // seleções continuam só com a bandeira).
    const fppUrl = code==="pt" ? federationLogoUrl("fpp") : null;
    const fppBadgeHtml = fppUrl ? `<img class="nat-flag fed-badge" src="${fppUrl}" alt="" title="Federação de Patinagem de Portugal">` : "";
    const bodyHtml = !conv
      ? `<p class="helptext">Ainda não há nenhuma convocatória registada para esta seleção nesta carreira.</p>`
      : (() => {
          const gr = conv.jogadores.filter(j=>j.pos==="GR"), j = conv.jogadores.filter(j=>j.pos!=="GR");
          const provaLogoUrl = competitionLogoUrl(selecaoCompetitionId(conv.prova));
          const provaLogoHtml = provaLogoUrl ? `<img class="comp-badge-inline" src="${provaLogoUrl}" alt="" title="${escapeHtml(selecaoCompetitionName(conv.prova))}">` : "";
          return `<div class="pm-retro-subline">${provaLogoHtml}Última convocatória — ${escapeHtml(selecaoCompetitionName(conv.prova))} (${escapeHtml(conv.seasonLabel||seasonLabel(conv.season+1))})</div>
            <div class="pm-retro-section-lbl">Guarda-Redes</div>${gr.map(jogadorRowHtml).join("")}
            <div class="pm-retro-section-lbl">Jogadores de Campo</div>${j.map(jogadorRowHtml).join("")}`;
        })();
    selecaoModalBox.style.maxWidth = "560px";
    selecaoModalBox.style.padding = "20px";
    selecaoModalBox.innerHTML = `
      <div class="pm-retro">
        <div class="pm-retro-titlebar">
          <span class="ttl">${selecaoLogoHtml(code, "nat-flag")}${fppBadgeHtml} Seleção de ${escapeHtml(nation.nome)}</span>
        </div>
        <div class="pm-retro-body">${bodyHtml}</div>
        <div class="pm-retro-actions">
          <button id="selecaoModalCloseBtn">Fechar</button>
        </div>
      </div>
    `;
    selecaoModal.classList.remove("hidden");
    document.getElementById("selecaoModalCloseBtn").addEventListener("click", () => { selecaoModal.classList.add("hidden"); });
  }

  // =================================================================
  // Player detail modal
  // =================================================================
  const playerModal = document.getElementById("playerModal");
  const playerModalBox = document.getElementById("playerModalBox");
  let currentModalPlayerCtx = null;
  let playerModalHistory = [];

  function moralColor(m){ return m>=60 ? "#3FA34D" : m>=35 ? "#F3C623" : "#D6402F"; }
  function contentmentInfo(moral){
    if(moral>=70) return { text:"😊 Muito contente no clube", bg:"rgba(63,163,77,0.15)", color:"#2f7a3a" };
    if(moral>=45) return { text:"🙂 Satisfeito", bg:"rgba(243,198,35,0.18)", color:"#8a6d00" };
    return { text:"😠 Descontente com a situação no clube", bg:"rgba(214,64,47,0.15)", color:"var(--vermelho)" };
  }
  function fmtSalario(v){ return v.toLocaleString("pt-PT") + " €/mês"; }

  // Entry point: called from a roster/team list — starts a fresh navigation trail.
  function stablePotentialNoise(player, team){
    const key = `${player.id||player.name}|${team.id}|potencial-observado`;
    const rng = makeSeededRng(key);
    const ownTeam = team.id===state.userTeamId;
    const appearances = player.season ? (player.season.jogos||0) : 0;
    const historyDepth = Array.isArray(player.historico) ? player.historico.length : 0;
    const confidence = clamp((ownTeam?35:10)+appearances*3+historyDepth*2, 10, 95);
    const errorRange = confidence>=80?1:confidence>=60?2:confidence>=35?3:4;
    return { estimate:clampAttr(player.potential + seededRnd(rng,-errorRange,errorRange)), confidence };
  }
  function visiblePotentialLabel(player, team){
    const {estimate,confidence}=stablePotentialNoise(player,team);
    if(confidence<25) return "Incerta";
    const margin=estimate-overall(player);
    if(margin<=1) return "Limitada";
    if(margin<=3) return "Regular";
    if(margin<=5) return "Interessante";
    if(margin<=7) return "Elevada";
    return "Excecional";
  }
  function potentialConfidenceLabel(player, team){
    const c=stablePotentialNoise(player,team).confidence;
    return c>=80?"Muito boa":c>=60?"Boa":c>=35?"Razoável":"Baixa";
  }
  function confidenceLabel(c){ return c>=80?"Muito boa":c>=60?"Boa":c>=35?"Razoável":"Baixa"; }

  // Generaliza stablePotentialNoise (que já só existia para o potencial) a qualquer atributo:
  // estimativa com ruído determinístico (semente por jogador+clube+atributo), com confiança maior
  // para atributos físicos (fáceis de avaliar à vista) do que técnicos/mentais, e que sobe com
  // jogos vistos, histórico, proximidade de divisão/zona, e um relatório de scouting pago
  // (scoutingReportFor, 04-financas.js). Um jogador do nosso plantel é sempre exato — nunca há
  // nevoeiro sobre o que já é nosso.
  function isMinePlayerTeam(team){
    const my = state.userTeamId, myB = state.teams[my] && state.teams[my].equipaBId;
    return team.id===my || team.id===myB;
  }
  function stableAttrNoise(player, team, key){
    if(isMinePlayerTeam(team) || experienciaExataParaUtilizador(player)) return { estimate: player.attrs[key], confidence:100, resolved:true };
    const rng = makeSeededRng(`${player.id||player.name}|${team.id}|attr-${key}`);
    const appearances = player.season ? (player.season.jogos||0) : 0;
    const historyDepth = Array.isArray(player.historico) ? player.historico.length : 0;
    const physical = attrIsPhysical(key);
    const tier = scoutingDistanceTier(team);
    const report = scoutingReportFor(player.id);
    // Um relatório pago resolve muito bem os atributos físicos, mas deixa sempre uma margem
    // pequena nos técnicos/mentais — mesmo um olheiro profissional se pode enganar um pouco a
    // avaliar criatividade ou visão de jogo, nunca com a mesma certeza de avaliar velocidade. Um
    // relatório "rápido" (2026-09-05) dá um bónus bem menor do que o completo — cobre o alvo mais
    // depressa e mais barato, mas fica sempre mais impreciso.
    const reportBonus = !report ? 0 : (report.tipo==="rapido" ? (physical?30:15) : (physical?62:36));
    // Reputação do jogador (2026-09-05): discutido com o utilizador — sem isto, um veterano
    // internacional e um jovem da formação partiam com o mesmo nevoeiro máximo na primeira época,
    // antes de qualquer jogo ser visto. Um jogador já reputado é, na prática, uma cara conhecida —
    // sobra o risco genuíno sobretudo para quem ainda não construiu reputação nenhuma.
    const reputationBonus = Math.round((player.reputacaoJogador||0)*.3);
    const base = (physical?24:9) - SCOUTING_DISTANCE_PROFILE[tier].confidencePenalty + reportBonus + reputationBonus;
    const confidence = clamp(base + appearances*2.5 + historyDepth*1.5, 5, 99);
    const errorRange = confidence>=90?0:confidence>=70?1:confidence>=50?2:confidence>=30?3:5;
    return { estimate: clampAttr(player.attrs[key] + seededRnd(rng,-errorRange,errorRange)), confidence, resolved:confidence>=90 };
  }
  // Ficha de atributos "tal como o utilizador a vê" — para um jogador nosso é sempre igual a
  // player.attrs; para um jogador de outro clube, cada atributo passa por stableAttrNoise. É a
  // partir DESTA ficha (nunca da real) que se deriva o OVR mostrado, para nunca mostrar um OVR
  // estimado inconsistente com os atributos estimados ao lado.
  function visibleAttrsObject(player, team){
    if(isMinePlayerTeam(team) || experienciaExataParaUtilizador(player)) return player.attrs;
    const out = {};
    Object.keys(player.attrs).forEach(key=>{ out[key]=stableAttrNoise(player,team,key).estimate; });
    return out;
  }
  function visibleOverall(player, team){
    return (isMinePlayerTeam(team) || experienciaExataParaUtilizador(player)) ? overall(player) : overallFromAttrs(player.pos, visibleAttrsObject(player,team));
  }

  function openPlayerModal(teamId, playerId, tab){
    // Um nome de jogador pode ser clicado a partir de dentro do modal da Seleção (a lista da
    // última convocatória) — sem isto, os dois modais ficavam sobrepostos (o do jogador escondido
    // atrás do da seleção, por vir antes no DOM). Fecha-o primeiro, tal como openTreinadorModal já
    // fazia com playerModal.
    selecaoModal.classList.add("hidden");
    playerModalHistory = [];
    renderPlayerModalContent(teamId, playerId, false, tab);
  }
  // Called when clicking a teammate from inside the modal — remembers where we came from.
  function navigateToPlayer(teamId, playerId){
    if(currentModalPlayerCtx) playerModalHistory.push(currentModalPlayerCtx);
    renderPlayerModalContent(teamId, playerId);
  }
  function goBackPlayerModal(){
    const prev = playerModalHistory.pop();
    if(prev) renderPlayerModalContent(prev.teamId, prev.playerId, true);
    else playerModal.classList.add("hidden");
  }
  // =================================================================
  // Ficha do clube — página inteira (Fase 6 da Academia e Juvenis, 2026-09-22, decisão 6 do
  // utilizador). Substitui por completo o antigo modal openClubModal/renderClubModalContent/
  // clubModal: qualquer clique num nome de clube (.jr-team-link[data-team], listener global mais
  // abaixo) passa a navegar para a .hub-view "ficha" (state.viewedFichaTeamId + setView("ficha")),
  // com um separador novo "Academia" a par dos 3 já existentes (Clube/Plantel/Títulos), em vez de
  // abrir um popup. O botão "‹ Voltar" e o histórico de navegação (state.viewHistory/goBackView,
  // 01-nucleo.js) já tratam da navegação de volta automaticamente, sem plumbing novo. Continua a
  // construir-se sempre a partir de state.teams[teamId] (dados globais), por isso funciona a
  // partir de QUALQUER sítio onde o nome de um clube apareça, incluindo os clubes da nuvem
  // europeia (embora estes, tal como os de 3ª divisão, nunca tenham separador Academia com dados
  // — academyEligible(team) é falso para ambos).
  let cmActiveTab = "clube";
  const CAPACIDADE_FINANCEIRA_LABEL = v => v>=80?"Excelente":v>=65?"Muito boa":v>=50?"Boa":v>=35?"Modesta":"Fraca";
  function clubCompetitionLabel(team){
    if(team.nuvemEuropeia){
      const paisLabel = { fr:"França", de:"Alemanha", ch:"Suíça", en:"Inglaterra", at:"Áustria" }[team.pais] || team.pais;
      return `Nuvem Europeia — ${paisLabel} (não jogável)`;
    }
    const comp = Object.values(state.competitions).find(c=>Array.isArray(c.teamIds) && c.teamIds.includes(team.id));
    return comp ? competitionLabel(comp.id) : "—";
  }
  // Pedido do utilizador (2026-09-26):
  // - "os planteis das equipas têm de estar arrumados por posição" — antes só ordenava por OVR
  //   (visibleOverall), misturando GR/DEF-MED/AVÇ; passa a agrupar por posição primeiro
  //   (playerPositionSortKey, o mesmo critério já usado na convocatória), com o OVR como
  //   critério de desempate dentro de cada posição.
  // - "no plantel, há sobreposição" / "o nome dos jogadores está muito longe da idade, ovl etc." —
  //   grid-template-columns antigo ("24px 1fr 34px 40px 40px") tinha duas falhas: a coluna de
  //   posição (40px) já não chegava para "DEF/MED" ao tamanho de letra actual (a etiqueta
  //   transbordava por cima do OVR ao lado), e a coluna do nome em 1fr esticava-se pelo painel
  //   todo, empurrando idade/posição/OVR para muito longe do nome à medida que o painel é largo.
  //   Nome passa a minmax(0,210px) (não estica mais do que isso) e sobra um 1fr no FIM (depois do
  //   OVR) a absorver o espaço a mais, para as colunas ficarem sempre coladas ao nome.
  function clubPlantelRowsHtml(team){
    const cedidos = empEmprestadosFora(team.id), cedidoDest = {}; cedidos.forEach(x=>{ cedidoDest[x.p.id] = x.dest; });
    return team.players.concat(cedidos.map(x=>x.p)).sort((a,b)=>playerPositionSortKey(a)-playerPositionSortKey(b) || visibleOverall(b,team)-visibleOverall(a,team)).map(p => `
      <div class="fixture-row ${cedidoDest[p.id]?'roster-cedido':''}" style="grid-template-columns:26px 22px minmax(0,210px) 30px 76px 40px 1fr;font-size:15px;">
        <div>${p.num}</div>
        <div>${nationalityFlagHtml(p)}</div>
        <div><button class="playername-btn" data-team="${cedidoDest[p.id]?cedidoDest[p.id].id:team.id}" data-id="${p.id}">${playerNameHtml(p, cedidoDest[p.id] ? {cedido:true} : undefined)}</button>${cedidoDest[p.id] ? ` <span class="roster-cedido-dest">→ ${escapeHtml(cedidoDest[p.id].name)}</span>` : ''}</div>
        <div style="text-align:center;">${p.age}</div>
        <div><span class="pos-badge ${p.pos==='GR'?'gr':'j'}">${linhaAbbrev(p)}</span></div>
        <div style="text-align:center;">${visibleOverall(p,team)}</div>
      </div>`).join("");
  }
  function clubTitulosHtml(team){
    const titulos = (team.titulosClube||[]).slice().sort((a,b)=>(b.epoca||"").localeCompare(a.epoca||""));
    if(!titulos.length) return `<p class="pm-retro-subline">Sem títulos registados ainda.</p>`;
    return `<table class="pm-retro-stat-table" style="text-align:left;">
      <tr><th>Época</th><th>Competição</th></tr>
      ${titulos.map(t=>`<tr><td>${escapeHtml(t.epoca||"—")}</td><td>${escapeHtml(t.nome||t.competicao||"—")}</td></tr>`).join("")}
    </table>`;
  }
  const ACADEMY_BRACKET_LABEL = { sub13:"Sub-13", sub15:"Sub-15", sub17:"Sub-17", sub19:"Sub-19" };
  // Lista de jogadores de um escalão da academia, mesmo formato de clubPlantelRowsHtml (nome
  // clicável via .playername-btn, respeitando informação imperfeita para clubes que não são o
  // do utilizador através de visibleOverall/playerNameHtml — nenhum código novo de incerteza,
  // reaproveita stableAttrNoise/visibleOverall tal como o resto da ficha do jogador).
  function academyBracketRowsHtml(team, bracket){
    const players = team.academy.brackets[bracket].players;
    if(!players.length) return `<p class="pm-retro-subline">Sem jogadores neste escalão.</p>`;
    // Mesmo tratamento de clubPlantelRowsHtml acima (arrumado por posição, colunas sem
    // sobreposição, bandeirinha de nacionalidade) — só sem a coluna de número (irrelevante antes
    // da promoção, ver comentário original abaixo).
    return players.slice().sort((a,b)=>playerPositionSortKey(a)-playerPositionSortKey(b) || visibleOverall(b,team)-visibleOverall(a,team)).map(p => `
      <div class="fixture-row" style="grid-template-columns:22px minmax(0,210px) 30px 76px 40px 1fr;font-size:15px;">
        <div>${nationalityFlagHtml(p)}</div>
        <div><button class="playername-btn" data-team="${team.id}" data-id="${p.id}">${playerNameHtml(p)}</button></div>
        <div style="text-align:center;">${p.age}</div>
        <div><span class="pos-badge ${p.pos==='GR'?'gr':'j'}">${linhaAbbrev(p)}</span></div>
        <div style="text-align:center;">${visibleOverall(p,team)}</div>
      </div>`).join("");
  }
  function clubAcademiaHtml(team){
    if(!academyEligible(team) || !team.academy){
      return `<p class="pm-retro-subline">${team.divisaoAtual==="3div" ? "Clubes da 3.ª divisão não têm academia — é criada automaticamente no momento em que o clube sobe à 2.ª divisão." : team.nuvemEuropeia ? "Clubes da nuvem europeia (placeholders, não jogáveis) não têm academia." : "Este clube ainda não tem academia."}</p>`;
    }
    return `
      <div class="pm-retro-row"><span class="lbl">Nível da Academia</span><span class="val">${team.academy.level}/10</span></div>
      <div class="pm-retro-row"><span class="lbl">Reputação</span><span class="val">${team.academy.reputation}</span></div>
      ${ACADEMY_BRACKETS.map(b=>`
        <div class="pm-retro-section-lbl">${ACADEMY_BRACKET_LABEL[b]} (${team.academy.brackets[b].players.length})</div>
        ${academyBracketRowsHtml(team, b)}
      `).join("")}
    `;
  }
  // Separador "Transferências" da Ficha do Clube (2026-10-04, pedido do utilizador: "a folha dos
  // clubes deve ter um separador Transferências onde se pode consultar entradas e saidas por cada
  // ano") — lê o ledger partilhado state.clubMovements (alimentado em registerPlayerEntry/
  // releasePlayerToFreeAgency/returnSeasonLoans/processDefesoMarket, 04-financas.js), agrupado por
  // época (mais recente primeiro) e, dentro de cada época, separado em Entradas/Saídas. Nomes de
  // jogador aparecem como texto simples (não clicáveis): um movimento antigo pode referir-se a um
  // jogador que entretanto mudou outra vez de clube, e abrir a ficha errada seria pior do que não
  // abrir nenhuma.
  function clubMovementTypeLabel(tipo, direction, hasRealCounterpart){
    if(tipo==="transferencia") return direction==="entrada" ? "Transferência (compra)" : "Transferência (venda)";
    if(tipo==="livre") return hasRealCounterpart ? "Pré-contrato" : (direction==="entrada" ? "Assinatura livre" : "Saída");
    if(tipo==="emprestimo") return direction==="entrada" ? "Empréstimo (chegada)" : "Cedido por empréstimo";
    if(tipo==="fim-emprestimo") return direction==="entrada" ? "Regresso de empréstimo" : "Fim de empréstimo";
    if(tipo==="dispensa") return "Dispensa";
    if(tipo==="fim-contrato") return "Fim de contrato";
    return tipo||"—";
  }
  function clubTransferenciasHtml(team){
    const movs = (state.clubMovements||[]).filter(m=>m.clubId===team.id);
    if(!movs.length) return `<p class="pm-retro-subline">Sem movimentos registados ainda.</p>`;
    const bySeason = {};
    movs.forEach(m=>{ (bySeason[m.season]=bySeason[m.season]||[]).push(m); });
    const seasons = Object.keys(bySeason).map(Number).sort((a,b)=>b-a);
    const rowsTable = list => list.length
      ? `<table class="pm-retro-stat-table" style="text-align:left;width:100%;">
          <tr><th>Jogador</th><th>Tipo</th><th>Clube</th><th style="text-align:right;">Valor</th></tr>
          ${list.map(m=>`<tr><td>${escapeHtml(m.playerName||"—")}</td><td>${escapeHtml(clubMovementTypeLabel(m.tipo,m.direction,!!m.counterpartId))}</td><td>${escapeHtml(m.counterpartName||"—")}</td><td style="text-align:right;">${m.valor?fmtMoney(m.valor):"—"}</td></tr>`).join("")}
        </table>`
      : `<p class="pm-retro-subline">Sem movimentos nesta direção.</p>`;
    return seasons.map(season=>{
      const all = bySeason[season];
      const entradas = all.filter(m=>m.direction==="entrada");
      const saidas = all.filter(m=>m.direction==="saida");
      return `
        <div class="pm-retro-section-lbl">${escapeHtml(seasonLabel(season))}</div>
        <div class="pm-retro-subline" style="margin:2px 0 6px;"><b>Entradas (${entradas.length})</b></div>
        ${rowsTable(entradas)}
        <div class="pm-retro-subline" style="margin:12px 0 6px;"><b>Saídas (${saidas.length})</b></div>
        ${rowsTable(saidas)}
      `;
    }).join('<hr style="margin:16px 0;border:none;border-top:1px solid var(--borda);">');
  }
  // Separador Staff (Fase 3, 2026-09-22): resumo do treinador do clube — ou, no próprio clube do
  // utilizador, do gestor humano (que é quem efectivamente comanda o clube, ver
  // activeCoachingStats, 08c-staff-treinadores.js) — com um botão para abrir a ficha completa,
  // idêntica à do jogador (renderTreinadorModalContent).
  function clubStaffHtml(team){
    const isMine = team.id === state.userTeamId;
    if(isMine){
      const g = ensureManagerCareer();
      const pct = treinadorRecordPct(g.mandatoAtual);
      return `
        <div class="pm-retro-subline">Neste clube, és tu quem comanda — as tuas tácticas e transferências continuam sempre manuais. O teu perfil (ver Carreira do treinador) é que influencia gradualmente a cultura e a Academia do clube.</div>
        <div class="pm-retro-row"><span class="lbl">Treinador</span><span class="val">${escapeHtml(state.managerName||"—")} <span class="helptext">(tu)</span></span></div>
        <div class="pm-retro-row"><span class="lbl">Mandato atual</span><span class="val">${g.mandatoAtual.jogos} jogos · ${g.mandatoAtual.vitorias}V-${g.mandatoAtual.empates}E-${g.mandatoAtual.derrotas}D (${pct}%V)</span></div>
        <button class="btn btn-ghost" id="fichaStaffOpenBtn" data-kind="gestor" style="margin-top:8px;">Ver a tua ficha completa</button>
      `;
    }
    if(!team.treinador){
      if(team.divisaoAtual==="3div") return `<p class="pm-retro-subline">Clubes da 3.ª divisão não têm treinador próprio — dependem da IA genérica.</p>`;
      if(team.nuvemEuropeia) return `<p class="pm-retro-subline">Clubes da nuvem europeia (placeholders, não jogáveis) não têm treinador próprio.</p>`;
      // Mercado de treinadores (2026-09-23): vaga em aberto (despedimento ou saída voluntária —
      // ver fireTreinador/hireTreinadorForVacancy, 08c-staff-treinadores.js) — "deve ser possível
      // concorrer ao lugar", pedido explícito do utilizador, daqui mesmo (ver listener em
      // renderClubFichaView).
      if(team.treinadorVacancia){
        return `
          <p class="pm-retro-subline">Clube sem treinador — vaga em aberto desde ${fmtDateShort(team.treinadorVacancia.desde)}.</p>
          <button class="btn btn-ghost" id="fichaCandidatarBtn" data-team="${team.id}" style="margin-top:8px;">Candidatar-me a este lugar</button>
        `;
      }
      return `<p class="pm-retro-subline">Este clube ainda não tem treinador.</p>`;
    }
    const tr = team.treinador;
    const pct = treinadorRecordPct(tr.mandatoAtual);
    return `
      <div class="pm-retro-row"><span class="lbl">Treinador</span><span class="val">${escapeHtml(tr.nome)}</span></div>
      <div class="pm-retro-row"><span class="lbl">Nacionalidade</span><span class="val">${escapeHtml(tr.nacionalidade||"Portuguesa")}</span></div>
      <div class="pm-retro-row"><span class="lbl">Mandato atual</span><span class="val">${tr.mandatoAtual.jogos} jogos · ${tr.mandatoAtual.vitorias}V-${tr.mandatoAtual.empates}E-${tr.mandatoAtual.derrotas}D (${pct}%V)</span></div>
      <button class="btn btn-ghost" id="fichaStaffOpenBtn" data-kind="treinador" style="margin-top:8px;">Ver ficha completa</button>
    `;
  }
  function renderClubFichaView(){
    const teamId = state.viewedFichaTeamId;
    const team = state.teams[teamId];
    const body = document.getElementById("fichaBody");
    if(!team || !body) return;
    if(!team.nuvemEuropeia) initClubFinance(team);
    const isMine = teamId === state.userTeamId;
    const fEstado = !team.nuvemEuropeia ? financialState(team) : null;
    const clubeHtml = `
      <div class="pm-retro-row"><span class="lbl">Divisão / Competição</span><span class="val">${clubCompetitionLabel(team)}</span></div>
      <div class="pm-retro-row"><span class="lbl">Reputação</span><span class="val">${team.reputacao}</span></div>
      <div class="pm-retro-row"><span class="lbl">Condições de Treino</span><span class="val">${escapeHtml(team.condicoesTreino||"—")}</span></div>
      <div class="pm-retro-row"><span class="lbl">Capacidade Financeira</span><span class="val">${CAPACIDADE_FINANCEIRA_LABEL(team.capacidadeFinanceira||0)}</span></div>
      ${fEstado ? `<div class="pm-retro-row"><span class="lbl">Situação Financeira</span><span class="val">${escapeHtml(fEstado.label)}</span></div>` : ''}
      ${isMine && team.financeiro ? `<div class="pm-retro-row"><span class="lbl">Saldo</span><span class="val">${fmtMoney(team.financeiro.saldo)}</span></div>` : ''}
      <div class="pm-retro-row"><span class="lbl">Pavilhão</span><span class="val">${escapeHtml(team.pavilhao||"—")}</span></div>
      <div class="pm-retro-row"><span class="lbl">Cidade</span><span class="val">${escapeHtml(team.cidadePavilhao||"—")}</span></div>
      <div class="pm-retro-row"><span class="lbl">Lotação</span><span class="val">${team.financeiro&&team.financeiro.capacidadePavilhao?`${team.financeiro.capacidadePavilhao} lugares`:"—"}</span></div>
    `;
    const plantelHtml = `
      <div class="pm-retro-subline" style="margin-bottom:6px;">${team.players.length} jogadores (${team.players.filter(p=>p.pos==="GR").length} GR / ${team.players.filter(p=>p.pos!=="GR").length} jog. de campo)${team.provisional?' <span class="provisional-tag">PROVISÓRIO</span>':''}</div>
      ${clubPlantelRowsHtml(team)}
    `;
    const titulosHtml = clubTitulosHtml(team);
    const academiaHtml = clubAcademiaHtml(team);
    const staffHtml = clubStaffHtml(team);
    const transferenciasHtml = clubTransferenciasHtml(team);
    const activeHtml = cmActiveTab==='clube' ? clubeHtml : cmActiveTab==='plantel' ? plantelHtml : cmActiveTab==='titulos' ? titulosHtml : cmActiveTab==='staff' ? staffHtml : cmActiveTab==='transferencias' ? transferenciasHtml : academiaHtml;
    const fichaCrestUrl = clubCrestUrl(team.id);
    const fichaBadgeHtml = fichaCrestUrl
      ? `<span class="dot has-crest" style="width:22px;height:22px;display:inline-block;vertical-align:middle;margin-right:6px;"><img src="${fichaCrestUrl}" alt="" class="crest-img"></span>`
      : `<span class="swatch" style="width:12px;height:12px;border-radius:3px;background:${clubDisplayColor(team)};display:inline-block;margin-right:6px;"></span>`;
    body.innerHTML = `
      <div class="pm-retro">
        <div class="pm-retro-titlebar">
          <span class="ttl">${fichaBadgeHtml}${escapeHtml(team.name)}${isMine?' <span style="font-weight:400;color:var(--texto-mute);font-size:11px;">(o teu clube)</span>':''}</span>
        </div>
        <div class="pm-retro-tabs">
          <div class="pm-retro-tab ${cmActiveTab==='clube'?'active':''}" data-tab="clube">Clube</div>
          <div class="pm-retro-tab ${cmActiveTab==='plantel'?'active':''}" data-tab="plantel">Plantel</div>
          <div class="pm-retro-tab ${cmActiveTab==='titulos'?'active':''}" data-tab="titulos">Títulos</div>
          <div class="pm-retro-tab ${cmActiveTab==='transferencias'?'active':''}" data-tab="transferencias">Transferências</div>
          <div class="pm-retro-tab ${cmActiveTab==='academia'?'active':''}" data-tab="academia">Academia</div>
          <div class="pm-retro-tab ${cmActiveTab==='staff'?'active':''}" data-tab="staff">Staff</div>
        </div>
        <div class="pm-retro-body">${activeHtml}</div>
      </div>
    `;
    body.querySelectorAll(".pm-retro-tab").forEach(t=>{
      t.addEventListener("click", () => { cmActiveTab = t.getAttribute("data-tab"); renderClubFichaView(); });
    });
    body.querySelectorAll(".playername-btn").forEach(btn=>{
      btn.addEventListener("click", () => openPlayerModal(btn.getAttribute("data-team"), btn.getAttribute("data-id")));
    });
    const staffOpenBtn = document.getElementById("fichaStaffOpenBtn");
    if(staffOpenBtn){
      staffOpenBtn.addEventListener("click", () => openTreinadorModal(staffOpenBtn.getAttribute("data-kind"), team.id));
    }
    // Mercado de treinadores (2026-09-23): candidatura directa a partir da Ficha do Clube, para
    // um clube com uma vaga em aberto (ver clubStaffHtml acima).
    const candidatarBtn = document.getElementById("fichaCandidatarBtn");
    if(candidatarBtn){
      candidatarBtn.addEventListener("click", () => {
        const r = applyForManagerJob(candidatarBtn.getAttribute("data-team"), state.currentDate);
        alert(r.outcome==="recusa" ? r.reason : "Candidatura enviada — a direção vai analisar e responder em breve.");
        renderClubFichaView();
      });
    }
  }
  // Navegação para a Ficha do Clube (Fase 6, mesmo padrão de openCompetitionView): fecha o modal
  // de jogador (se estiver aberto), define o clube em vista e navega para a .hub-view "ficha".
  // Separador por omissão (decisão 6 do utilizador): "Plantel" para o próprio clube do utilizador
  // ("O meu plantel vejo pelo separador do plantel... quando aparece o nome da minha equipa, ao
  // clicar vai para esse separador"), "Clube" para qualquer outro.
  function openClubFicha(teamId, tab){
    playerModal.classList.add("hidden");
    state.viewedFichaTeamId = teamId;
    // Pedido do utilizador (2026-09-26): "quando se clica num clube, o menu que abre tem de ser
    // logo o plantel" — antes só o clube do próprio utilizador abria directamente no separador
    // Plantel (os restantes clubes abriam em "Clube"); passa a ser sempre Plantel por omissão,
    // para qualquer clube, a não ser que quem chamou peça outro separador explicitamente (ex.
    // "Ver ficha completa" no Resumo, ou o separador Academia a partir de um jogador juvenil).
    cmActiveTab = tab || "plantel";
    setView("ficha");
  }
  // Adaptador de pesquisa (Fase 6): um jogador pode estar no plantel real (team.players) ou,
  // desde a Academia e Juvenis, num dos 4 escalões de team.academy.brackets.* — nunca nos dois em
  // simultâneo (ver 08b-academia-juvenis.js). Usado por renderPlayerModalContent para conseguir
  // abrir a ficha de um jogador juvenil a partir do separador Academia.
  function findPlayerAnywhere(teamId, playerId){
    const team = state.teams[teamId];
    if(!team) return null;
    const inSquad = team.players.find(p=>p.id===playerId);
    if(inSquad) return inSquad;
    return findPlayerInAcademy(teamId, playerId);
  }
  // Delegação de eventos: um único listener global cobre todos os nomes de equipa clicáveis em
  // qualquer parte da interface (notícias, classificação, calendário, playoff, estatísticas...),
  // em vez de registar um listener novo sempre que uma lista é (re)desenhada.
  document.addEventListener("click", (e) => {
    const link = e.target.closest(".jr-team-link[data-team]");
    if(link){ e.preventDefault(); openClubFicha(link.getAttribute("data-team")); }
    // Pedido do utilizador (2026-09-14): a notícia de aceitação do fee de transferência (quando é
    // o utilizador a comprar) deve poder abrir já a ficha do jogador, com a proposta de contrato
    // pré-preenchida (externalTransferPanelHtml já a mostra forçada a aberto assim que o fee está
    // acordado) — mesma delegação global usada acima para os nomes de clube clicáveis, porque a
    // notícia pode já não estar visível quando o botão é clicado (o feed é reconstruído a cada dia).
    const contractBtn = e.target.closest(".news-open-contract[data-team]");
    if(contractBtn){
      e.preventDefault();
      // Renovação (2026-09-16, pedido do utilizador): ao contrário de transferência/pré-contrato,
      // abrir a ficha do jogador não basta — a secção de contrato (pmContractNegBox) só existe no
      // separador "Pessoal" da ficha (não no separador "Perfil", que é onde a ficha abre por
      // omissão), e o próprio cartão de negociação só aparece forçado a aberto quando
      // state.uiNegotiationOpenId já está marcado como 'renov-'+id (mesmo mecanismo que o botão
      // "Renovar" já usa manualmente). Sem as duas coisas, o botão abriria a ficha errada, sem
      // nada visível sobre a contraproposta.
      const isRenov = contractBtn.hasAttribute("data-renov");
      if(isRenov) state.uiNegotiationOpenId = "renov-"+contractBtn.getAttribute("data-id");
      openPlayerModal(contractBtn.getAttribute("data-team"), contractBtn.getAttribute("data-id"), isRenov?"pessoal":undefined);
    }
    // Jogador livre (2026-09-16): sem clube de origem, não há ficha de jogador onde abrir a
    // negociação (renderPlayerModalContent exige o jogador no plantel de um team.id real) — vai
    // direto à secção de jogadores livres do Mercado, com o cartão já aberto.
    const freeAgentBtn = e.target.closest(".news-open-freeagent[data-id]");
    if(freeAgentBtn){
      e.preventDefault();
      state.uiNegotiationOpenId = freeAgentBtn.getAttribute("data-id")+"|livre-sign";
      mercadoIrPara("livres");
      setView("mercado");
      const card = document.querySelector(`.negotiation-card[data-negid="${freeAgentBtn.getAttribute("data-id")}|livre-sign"]`);
      if(card) card.scrollIntoView({behavior:"smooth", block:"center"});
    }
    // Proposta de um clube de IA pelo passe de um jogador nosso (2026-09-17, pedido do
    // utilizador): a notícia já mostra os termos, falta um caminho direto para responder — vai
    // ao separador Mercado, onde renderAiOffersSection já lista Aceitar/Contrapropor/Recusar
    // para esta proposta específica, e realça a linha correspondente.
    const aiOfferBtn = e.target.closest(".news-open-aioffer[data-offer]");
    if(aiOfferBtn){
      e.preventDefault();
      mercadoIrPara("negociacoes");
      setView("mercado");
      const row = document.querySelector(`.ai-offer-row[data-offer="${aiOfferBtn.getAttribute("data-offer")}"]`);
      if(row) row.scrollIntoView({behavior:"smooth", block:"center"});
    }
    // Correção (2026-09-14, pedido do utilizador: "os jogadores e as competições devem ser sempre
    // clicaveis, mesmo nas noticias"): ".playername-btn" já existia e já abria a ficha do jogador
    // em várias listas (plantel, ficha de clube, estatísticas, scouting), mas só através de
    // listeners locais registados depois de cada renderização — o feed de notícias nunca registava
    // nenhum, por isso um nome de jogador dentro de uma notícia nunca reagia a cliques. Este
    // listener global cobre qualquer ".playername-btn" com data-team+data-id definidos (o próprio
    // botão do plantel, sem data-team, continua a ser tratado pelo listener local existente em
    // rosterBody, que já sabe o clube certo através de plantelActiveTeamId()) — funciona onde quer
    // que o botão apareça, incluindo dentro do feed de notícias, reconstruído a cada dia.
    const playerBtn = e.target.closest(".playername-btn[data-team][data-id]");
    if(playerBtn){ e.preventDefault(); openPlayerModal(playerBtn.getAttribute("data-team"), playerBtn.getAttribute("data-id")); }
    // Mesmo princípio para nomes de competição (competitionLinkHtml, acima) — salta diretamente
    // para o separador Competições, já na competição indicada.
    const compBtn = e.target.closest(".jr-competition-link[data-competition]");
    if(compBtn){ e.preventDefault(); openCompetitionView(compBtn.getAttribute("data-competition")); }
    // Bandeira/nome de uma seleção nacional clicável (selecaoNationLinkHtml, 07h-selecoes.js) —
    // qualquer sítio onde apareça (classificação, calendário, histórico, notícias de sorteio/
    // campeão/convocatória), pedido do utilizador (2026-09-27). Abre openSelecaoModal com a
    // última convocatória dessa seleção.
    const selecaoBtn = e.target.closest("[data-selecao]");
    if(selecaoBtn){ e.preventDefault(); openSelecaoModal(selecaoBtn.getAttribute("data-selecao")); }
  });

  let pmActiveTab = "perfil";
  function attrValColor(v){ return v>=15 ? "#7CE38B" : v>=10 ? "#FFF3C4" : v>=6 ? "#F3C623" : "#FF6B5E"; }
  function fracStat(made, total){ return `${made||0}/${total||0}`; }
  function avgPt(total, games){
    if(!games || games<=0) return "—";
    return ((total||0)/games).toFixed(2).replace(".", ",");
  }

  // Aviso curto e transitório (não bloqueia a interface, ao contrário de alert()).
  function showTransientNotice(msg){
    let el = document.getElementById("transientNotice");
    if(!el){
      el = document.createElement("div"); el.id = "transientNotice";
      el.style.cssText = "position:fixed;left:50%;bottom:28px;transform:translateX(-50%);z-index:9999;background:#1d2636;color:#fff;border:1px solid rgba(255,255,255,.25);border-radius:10px;padding:10px 16px;font-size:16px;box-shadow:0 6px 24px rgba(0,0,0,.45);max-width:80vw;";
      document.body.appendChild(el);
    }
    el.textContent = msg; el.style.display = "block";
    clearTimeout(showTransientNotice._t);
    showTransientNotice._t = setTimeout(()=>{ el.style.display = "none"; }, 4500);
  }
  // Correção (pedido do utilizador, 2026-10-05: "não estou a conseguir clicar" no botão "Propor
  // contrato ao jogador" / no nome do jogador numa notícia de acordo): os botões das notícias
  // guardam o clube de ORIGEM no momento da notícia (data-team); se o jogador entretanto mudou de
  // equipa (A→B, empréstimo, outra transferência), findPlayerAnywhere(teamId) não o encontrava e
  // renderPlayerModalContent saía em silêncio — o clique parecia não fazer nada. Agora procura o
  // jogador em qualquer clube e, se já não existir em nenhum, avisa em vez de falhar calado.
  function resolvePlayerTeamId(teamId, playerId){
    if(state.teams[teamId] && findPlayerAnywhere(teamId, playerId)) return teamId;
    const found = Object.values(state.teams).find(t=>t.players.some(p=>p.id===playerId));
    if(found) return found.id;
    const inAcademy = Object.values(state.teams).find(t=>findPlayerInAcademy(t.id, playerId));
    return inAcademy ? inAcademy.id : null;
  }
  function renderPlayerModalContent(teamId, playerId, isBack, tab){
    const realTeamId = resolvePlayerTeamId(teamId, playerId);
    if(!realTeamId){
      const free = (state.freeAgents||[]).find(p=>p.id===playerId);
      showTransientNotice(free ? "Este jogador está agora livre — consulta a secção de jogadores livres do Mercado." : "Este jogador já não está disponível nesta equipa.");
      return;
    }
    teamId = realTeamId;
    const team = state.teams[teamId];
    if(!team) return;
    // Adaptador de pesquisa (Fase 6, Academia e Juvenis): o jogador pode estar no plantel real
    // (team.players) ou, desde a Academia, num dos 4 escalões de team.academy.brackets.* —
    // findPlayerAnywhere cobre os dois casos, para o separador Academia da Ficha do Clube
    // conseguir abrir a ficha de um jogador juvenil.
    const player = findPlayerAnywhere(teamId, playerId);
    if(!player) return;
    // Um jogador ainda na Academia (nunca promovido ao plantel real) tem sempre academyBracket
    // definido — ver generateAcademyOutfield/GK e a limpeza desse campo em
    // runAcademySub19ExitPass/ensureBTeamMinimums no momento da promoção/geração de emergência.
    // Serve para simplificar secções desta ficha que não fazem sentido antes da promoção
    // (mercado de transferências, empréstimo, estatuto no clube, titularidade).
    const isAcademyPlayer = !!player.academyBracket;
    // A equipa B do próprio clube do utilizador conta como "minha" para efeitos de gestão
    // (incluindo renovações de contrato) — é o utilizador quem a gere, não a IA.
    const myOwnBTeamId = state.teams[state.userTeamId] && state.teams[state.userTeamId].equipaBId;
    const isMine = teamId === state.userTeamId || teamId === myOwnBTeamId;
    // Jogador meu emprestado a outro clube: aqui não há opções de transferência nem de scouting (é meu),
    // só o estado do empréstimo e a escolha da equipa (A/B) a que regressa.
    const cedidoMeu = !isMine && empCedidoPeloUtilizador(player);
    currentModalPlayerCtx = { teamId, playerId };
    pmActiveTab = tab || (isBack ? pmActiveTab : "perfil");

    const isGR = player.pos==="GR";
    // Left column: technical skills, distinct set for GR vs outfield (JC)
    const techKeys = isGR
      ? [["reflexos","Reflexos"],["umParaUm","1 para 1"],["agilidade","Agilidade"],["concentracao","Concentração"],["meiaDistancia","Meia-Distância"]]
      : [["habilidade","Habilidade"],["drible","Drible"],["criatividade","Criatividade"],["finalizacao","Finalização"],["bolasParadas","Bolas Paradas"],["meiaDistancia","Meia-Distância"],["posicionamento","Posicionamento"],["desarme","Desarme"]];
    // Right column: physical & mental — GR sem velocidade/aceleração (não relevantes para guarda-redes)
    const physKeys = isGR
      ? [["forca","Força"],["agressividade","Agressividade"],["determinacao","Determinação"],["lideranca","Liderança"],["resistencia","Resistência"]]
      : [["forca","Força"],["velocidade","Velocidade"],["aceleracao","Aceleração"],["agressividade","Agressividade"],["determinacao","Determinação"],["lideranca","Liderança"],["resistencia","Resistência"]];

    const avgNota = player.season.notas.length ? avg(player.season.notas).toFixed(1) : "—";
    const contentment = contentmentInfo(player.moral);
    const contrato = player.contrato || { salarioMensal:0, anos:0 };
    // "Colegas de equipa": para um jogador da Academia, os colegas são os do mesmo escalão
    // (team.players nem sequer o contém) — para um jogador já promovido, o plantel real de sempre.
    const teammates = isAcademyPlayer
      ? team.academy.brackets[player.academyBracket].players.filter(p=>p.id!==player.id).sort((a,b)=>overall(b)-overall(a))
      : team.players.filter(p=>p.id!==player.id).sort((a,b)=>overall(b)-overall(a));

    const attrRow = (key, label) => {
      if(isMine){
        return `
      <div class="pm-retro-row">
        <span class="lbl">${label}</span>
        <span class="val" style="color:${attrValColor(Math.round(player.attrs[key]))};">${evolutionArrowHtml(player,key)}${Math.round(player.attrs[key])}</span>
      </div>`;
      }
      const noise = stableAttrNoise(player, team, key);
      const val = Math.round(noise.estimate);
      return `
      <div class="pm-retro-row">
        <span class="lbl">${label}</span>
        <span class="val" style="color:${attrValColor(val)};">${noise.resolved?'':'~'}${val}</span>
      </div>`;
    };

    // Painel de scouting (2026-09-05): só para jogadores que não são nossos e cujo clube pode ser
    // abordado (equipas B ficam já cobertas pelo aviso existente mais abaixo). Mostra o estado
    // atual (sem pedido / pedido em curso / relatório já disponível) e o custo de pedir um novo.
    const scoutingPanelHtml = () => {
      // Jogadores da Academia nunca aparecem no mercado de transferências nem são alvo de
      // scouting formal em v1 — não fazem sentido pedidos de relatório para quem ainda nem sequer
      // foi promovido ao plantel sénior.
      if(isMine || team.equipaPrincipalId || isAcademyPlayer) return '';
      const report = scoutingReportFor(player.id);
      if(report) return `<div class="market-status ok" style="margin-bottom:10px;">🔎 Relatório ${report.tipo==="rapido"?"rápido":"completo"} de scouting disponível — avaliação ${report.tipo==="rapido"?"mais fiável":"bastante fiável"}.</div>`;
      const pending = scoutingPendingRequestFor(player.id);
      if(pending) return `<div class="market-status no" style="margin-bottom:10px;">🔎 O nosso olheiro está a preparar o relatório ${pending.tipo==="rapido"?"rápido":"completo"} — disponível a partir de ${fmtDatePt(new Date(pending.readyDate).toISOString().slice(0,10))}.</div>`;
      const my = myTeam();
      const scoutingStore = my ? ensureTeamScouting(my) : null;
      const cfg = my ? scoutingLevelConfig(my) : null;
      if(my && scoutingStore.pedidos.length>=cfg.capacidade){
        return `<div class="market-status no" style="margin-bottom:10px;">🔎 Departamento de scouting no limite de pedidos em curso (nível ${scoutingStore.departamento.nivel}: máximo ${cfg.capacidade} em simultâneo).</div>`;
      }
      const saldo = my && my.financeiro ? my.financeiro.saldo : 0;
      const custoCompleto = scoutingReportCost(team,"completo");
      const custoRapido = scoutingReportCost(team,"rapido");
      const vales = scoutingStore ? scoutingStore.valesCompletos : 0;
      const botaoCompleto = cfg && cfg.completoDisponivel ? `<button class="btn btn-ghost" id="pmScoutRequestBtn">Pedir relatório completo (${vales>0?'grátis — vale disponível':`${custoCompleto.total.toLocaleString("pt-PT")} €`})</button>` : `<div class="helptext">Departamento amador (nível 0) — só consegue observações rápidas.</div>`;
      return `<div class="pm-postmatch-grid" style="margin-bottom:8px;">
          <div><b>Relatório completo</b><br>${cfg && cfg.completoDisponivel ? `${custoCompleto.total.toLocaleString("pt-PT")} € · ${custoCompleto.prazoDias} dia${custoCompleto.prazoDias>1?'s':''}` : '— não disponível'}</div>
          <div><b>Relatório rápido</b><br>${custoRapido.total.toLocaleString("pt-PT")} € · ${custoRapido.prazoDias} dia${custoRapido.prazoDias>1?'s':''}</div>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          ${botaoCompleto}
          <button class="btn btn-ghost" id="pmScoutRequestRapidoBtn">Pedir relatório rápido (${custoRapido.total.toLocaleString("pt-PT")} €)</button>
        </div>
        ${saldo<custoRapido.total ? `<div class="helptext" style="margin-top:4px;">Tesouraria atual: ${saldo.toLocaleString("pt-PT")} € — um pedido pago vai aumentar a dívida do clube.</div>` : ''}
      `;
    };

    const perfilHtml = `
      <div class="pm-retro-subline">
        <b>#${player.num} ${playerNameHtml(player)}</b> — ${isGR?"Guarda-Redes":(player.linha==="Avancado"?"Avançado":player.linha==="DefesaMedio"?"Defesa/Médio":"Jogador de Campo")} · Idade ${player.age}
        ${isMine ? `<input type="text" id="pmName" value="${escapeHtml(player.name)}" style="display:none;">` : ''}
      </div>
      ${(player.suspensoJogos||0)>0 ? `<div style="background:rgba(214,64,47,0.25);border:1px solid #FF6B5E;color:#FFD9D0;border-radius:4px;padding:6px 10px;font-size:11.5px;font-weight:700;margin-bottom:10px;">🚫 Suspenso — falta ${player.suspensoJogos} jogo${player.suspensoJogos>1?'s':''}</div>` : ''}
      ${(player.diasLesao||0)>0 ? `<div style="background:rgba(214,64,47,0.25);border:1px solid #FF6B5E;color:#FFD9D0;border-radius:4px;padding:6px 10px;font-size:11.5px;font-weight:700;margin-bottom:10px;">🚑 ${escapeHtml(lesBannerTexto(player))}</div>` : (player.readapt ? `<div style="background:rgba(232,176,26,0.18);border:1px solid #E8B01A;color:#FFE9A8;border-radius:4px;padding:6px 10px;font-size:11.5px;font-weight:700;margin-bottom:10px;">🩹 ${escapeHtml(lesTituloReadapt(player))}</div>` : '')}
      ${isMine ? cargaFichaHtml(player) : ''}
      ${!isMine && !cedidoMeu ? `<div id="pmScoutingBox">${scoutingPanelHtml()}</div>` : ''}
      <div class="pm-retro-cols">
        <div>
          <div class="pm-retro-section-lbl">Técnica</div>
          ${techKeys.map(([k,l])=>attrRow(k,l)).join("")}
        </div>
        <div>
          <div class="pm-retro-section-lbl">Físico &amp; Mental</div>
          ${physKeys.map(([k,l])=>attrRow(k,l)).join("")}
        </div>
      </div>
      ${!isMine ? `<div class="pm-retro-subline" style="margin-top:6px;">Confiança da avaliação: ${confidenceLabel(stableAttrNoise(player,team,isGR?"reflexos":"habilidade").confidence)}. ${scoutingReportFor(player.id)?'':'Atributos marcados com "~" são uma estimativa, não o valor real.'}</div>` : ''}
      <div style="margin-top:10px;">
        <div class="pm-retro-row"><span class="lbl">Moral</span><span class="val" style="color:${moralColor(player.moral)};">${player.moral.toFixed(1)}</span></div>
        <div class="pm-retro-row"><span class="lbl">Condição</span><span class="val" style="color:${fitnessColor(player.condicao!=null?player.condicao:100)};">${(player.condicao!=null?player.condicao:100).toFixed(1)}%</span></div>
      </div>
      <div style="margin-top:6px;"><span class="pm-contentment" style="background:${contentment.bg};color:${contentment.color};">${contentment.text}</span></div>

      <div class="pm-retro-section-lbl">Estatísticas — Época ${seasonLabel(state.season)}</div>
      <table class="pm-retro-stat-table">
        <thead><tr>
          <th>J</th><th>G</th><th>A</th><th>🟨</th><th>🟦</th><th>🟥</th>
          ${isGR ? `<th>Pén. Def.</th><th>LD Def.</th>` : `<th>Pén.</th><th>LD</th>`}
          <th>Média</th><th>MVP</th>
        </tr></thead>
        <tbody><tr>
          <td>${player.season.jogosTitular||0} (${player.season.jogosSuplente||0})</td><td>${player.season.golos}</td><td>${player.season.assistencias}</td>
          <td>${player.season.amarelos||0}</td><td>${player.season.azuis||0}</td><td>${player.season.vermelhos||0}</td>
          ${isGR
            ? `<td>${fracStat(player.season.penaltisDefendidos, player.season.penaltisSofridos)}</td><td>${fracStat(player.season.livresDiretosDefendidos, player.season.livresDiretosSofridos)}</td>`
            : `<td>${fracStat(player.season.penaltisMarcados, player.season.penaltisTentados)}</td><td>${fracStat(player.season.livresDiretosMarcados, player.season.livresDiretosTentados)}</td>`}
          <td>${avgNota}</td><td>${player.season.mvp||0}</td>
        </tr></tbody>
      </table>
      <div class="pm-retro-subline" style="margin-top:8px;">Carreira: ${player.career.jogos} jogos, ${player.career.golos} golos, ${player.career.assistencias} assist., ${player.career.amarelos||0}🟨 ${player.career.azuis||0}🟦 ${player.career.vermelhos||0}🟥</div>
      ${isGR ? `
      <div class="pm-retro-section-lbl">Golos Sofridos</div>
      <table class="pm-retro-stat-table">
        <thead><tr><th>Jogos (época)</th><th>Sofridos (época)</th><th>Média (época)</th><th>Sofridos (carreira)</th><th>Média (carreira)</th></tr></thead>
        <tbody><tr>
          <td>${player.season.jogos}</td>
          <td>${player.season.golosSofridos||0}</td>
          <td>${avgPt(player.season.golosSofridos, player.season.jogos)}</td>
          <td>${player.career.golosSofridos||0}</td>
          <td>${avgPt(player.career.golosSofridos, player.career.jogos)}</td>
        </tr></tbody>
      </table>` : ''}

      <div class="pm-retro-section-lbl">Colegas de equipa</div>
      <div class="pm-retro-teammates">
        ${teammates.map(p=>`<button data-team="${team.id}" data-id="${p.id}">${p.pos==='GR'?'🧤 ':''}${playerNameHtml(p)} · ${visibleOverall(p,team)}</button>`).join("")}
      </div>

      ${isAcademyPlayer
        ? `<div class="pm-retro-subline" style="margin-top:12px;">Jogador da Academia (${ACADEMY_BRACKET_LABEL[player.academyBracket]||player.academyBracket}) — ainda não integrado no plantel sénior. Só entra em jogo, no mercado de transferências ou na titularidade depois de promovido (ver separador Academia da Ficha do Clube).</div>`
        : isMine ? `
        <div style="margin-top:12px;">
          <label style="font-size:12px;display:flex;align-items:center;gap:6px;color:#E8D98A;">
            <input type="checkbox" id="pmTitular" ${player.titular?'checked':''}> É titular (próxima jornada)
          </label>
        </div>` : (cedidoMeu ? '' : team.equipaPrincipalId ? `<div id="pmExternalTransferBox" style="margin-top:12px;">${externalLoanOnlyPanelHtml(player,team,myTeam())}</div>` : `<div id="pmExternalTransferBox" style="margin-top:12px;">${externalTransferPanelHtml(player,team,myTeam())}</div>`)}
    `;

    const titulos = Array.isArray(player.titulos) ? player.titulos : [];
    const titulosCounts = {};
    titulos.forEach(t => { titulosCounts[t] = (titulosCounts[t]||0)+1; });
    const titulosHtml = titulos.length ? `
        <div class="eyebrow" style="margin:14px 0 8px;">Títulos (${titulos.length})</div>
        <ul style="margin:0;padding-left:18px;font-size:12.5px;line-height:1.8;">
          ${Object.entries(titulosCounts).map(([nome,n]) => `<li>${escapeHtml(nome)}${n>1?` ×${n}`:''}</li>`).join("")}
        </ul>
      ` : `<div class="eyebrow" style="margin:14px 0 8px;">Títulos</div><p class="pm-retro-subline">Sem títulos registados ainda.</p>`;

    const internacionalizacoesHtml = `
      <div class="eyebrow" style="margin:14px 0 8px;">Seleção Nacional</div>
      <div class="pm-retro-row"><span class="lbl">Internacionalizações</span><span class="val">${player.internacionalizacoes||0}</span></div>
      <div class="pm-retro-row"><span class="lbl">Golos pela Seleção</span><span class="val">${player.golosInternacional||0}</span></div>
    `;

    const currentSeasonHistory = {
      epoca: seasonLabel(state.season),
      clube: team.name,
      jogos: player.season.jogos||0,
      jogosTitular: player.season.jogosTitular||0,
      jogosSuplente: player.season.jogosSuplente||0,
      golos: player.season.golos||0,
      assistencias: player.season.assistencias||0,
      golosSofridos: player.season.golosSofridos||0,
      movimento: player.movimentoEntrada && player.movimentoEntrada.epoca===state.season && player.movimentoEntrada.clubeId===team.id
        ? {tipo:player.movimentoEntrada.tipo,valor:player.movimentoEntrada.valor||0} : null,
    };
    const historicalRows = (Array.isArray(player.historico) ? player.historico : [])
      .filter(h=>String(h.epoca)!==String(currentSeasonHistory.epoca))
      .concat(currentSeasonHistory)
      .sort((a,b)=>seasonSortValue(b.epoca)-seasonSortValue(a.epoca));
    const historicoHtml = historicalRows.length ? `
        <table class="pm-retro-stat-table" style="text-align:left;">
          <thead><tr><th style="text-align:left;">Época</th><th style="text-align:left;">Clube</th><th>Entrada</th><th>J</th><th>G</th><th>A</th></tr></thead>
          <tbody>
            ${historicalRows.map(h => {
              const jogosTxt = (h.jogosTitular!=null || h.jogosSuplente!=null)
                ? `${h.jogosTitular||0} (${h.jogosSuplente||0})`
                : `${h.jogos}`;
              const movimentoTxt = !h.movimento ? "—"
                : h.movimento.tipo==="livre" ? "Sem Custos"
                : h.movimento.tipo==="emprestimo" ? "Empréstimo"
                : Number(h.movimento.valor||0).toLocaleString("pt-PT")+"€";
              return `<tr><td style="text-align:left;">${escapeHtml(h.epoca)}</td><td style="text-align:left;">${escapeHtml(h.clube)}</td><td>${movimentoTxt}</td><td>${jogosTxt}</td><td>${h.golos}</td><td>${h.assistencias}</td></tr>`;
            }).join("")}
          </tbody>
        </table>
        <p class="pm-retro-subline" style="margin-top:6px;">J: jogos como titular (suplentes utilizados entre parênteses).</p>
        ${titulosHtml}
        ${internacionalizacoesHtml}
      ` : `<p class="pm-retro-subline">Sem histórico registado ainda. Fica gravado automaticamente no fim de cada época, ou importa o historial real (ex. zerozero.pt) pelo botão "✎ Plantel".</p>${titulosHtml}${internacionalizacoesHtml}`;

    function fmtDatePt(iso){
      if(!iso) return "—";
      const d = new Date(iso+"T00:00:00Z");
      return String(d.getUTCDate()).padStart(2,"0")+"/"+String(d.getUTCMonth()+1).padStart(2,"0")+"/"+d.getUTCFullYear();
    }
    const pessoalHtml = `
      <div class="pm-retro-row"><span class="lbl">Data de Nascimento</span><span class="val">${fmtDatePt(player.dataNascimento)} (${player.age} anos)</span></div>
      <div class="pm-retro-row"><span class="lbl">Nacionalidade</span><span class="val">${escapeHtml(player.nacionalidade||"Portuguesa")}${isPlayerDisplaced(player,team)?` <span class="helptext" title="Joga fora do país de origem — o clube paga ${fmtMoney(playerHousingCost(player))}/mês de alojamento, além do salário.">(deslocado)</span>`:""}</span></div>
      ${persLinhaFicha(player, team)}
      <div class="pm-retro-row"><span class="lbl">Perspetiva</span><span class="val">${visiblePotentialLabel(player, team)}</span></div>
      <div class="pm-retro-row"><span class="lbl">Confiança da avaliação</span><span class="val">${potentialConfidenceLabel(player, team)}</span></div>
      <div class="pm-retro-row"><span class="lbl">Satisfação no Clube</span><span class="val" style="color:${moralColor(player.satisfacao!=null?player.satisfacao:70)};">${(player.satisfacao!=null?player.satisfacao:70).toFixed(1)}</span></div>
      <div class="eyebrow" style="margin:14px 0 8px;">Contrato</div>
      <div class="pm-retro-row"><span class="lbl">Salário Mensal</span><span class="val">${fmtSalario(contrato.salarioMensal)}</span></div>
      <div class="pm-retro-row"><span class="lbl">Termina em</span><span class="val">${contrato.dataFim?fmtDatePt(contrato.dataFim):"—"}</span></div>
      <div class="pm-retro-row"><span class="lbl">Papel no plantel</span><span class="val">${ROLE_LABELS[contrato.papel]||"—"}</span></div>
      <div class="pm-retro-row"><span class="lbl">Estado</span><span class="val">${contractStatusLabel(player)}</span></div>
      ${isAcademyPlayer ? `<div class="pm-retro-row"><span class="lbl">Estatuto no clube</span><span class="val">Academia</span></div>` : isMine ? `<div class="pm-retro-row"><span class="lbl">Estatuto no clube</span><span class="val">
        <select id="pmEstatuto">
          <option value="">(Automático — ${playerSquadImportance(player,team).label})</option>
          ${PLAYER_STATUS_LEVELS.map(lvl=>`<option value="${lvl}" ${player.estatutoManual===lvl?'selected':''}>${lvl}</option>`).join("")}
        </select>
      </span></div>` : `<div class="pm-retro-row"><span class="lbl">Estatuto no clube</span><span class="val">${effectivePlayerEstatuto(player,team)}</span></div>`}
      ${player.emprestimo ? (cedidoMeu ? (() => {
        const l = player.emprestimo, pair = internalTransferPairForUser();
        const origemB = pair && l.ownerId === pair.b.id;
        const alvo = pair ? (origemB ? pair.a : pair.b) : null;
        return `
      <div class="eyebrow" style="margin:14px 0 8px;">Jogador cedido (é teu)</div>
      <div class="pm-retro-row"><span class="lbl">Emprestado a</span><span class="val">${teamLinkHtml(l.destinationId)}</span></div>
      <div class="pm-retro-row"><span class="lbl">Regresso previsto</span><span class="val">Final desta época</span></div>
      <div class="pm-retro-row"><span class="lbl">Salário suportado pelo destino</span><span class="val">${l.salaryShare}%</span></div>
      <div class="pm-retro-row"><span class="lbl">Papel prometido</span><span class="val">${ROLE_LABELS[l.papel]||"—"}</span></div>
      <div class="pm-retro-row"><span class="lbl">Cláusulas</span><span class="val">${empClausulasTexto(l.clausulas)}</span></div>
      ${pair ? `<div class="pm-retro-row"><span class="lbl">Plantel de origem</span><span class="val">${origemB ? "Equipa B" : "Equipa A"}</span></div>
      <div style="margin-top:8px;"><button class="btn btn-ghost" id="pmCedidoMoveBtn" data-target="${alvo.id}">${origemB ? "Passar para Equipa A" : "Passar para Equipa B"}</button></div>` : ''}
      <div class="market-status no" style="margin-top:10px;">Só pode jogar no clube que o recebeu, e continua na tua lista do plantel até regressar. As transferências só se fazem quando regressar.</div>`;
      })() : team.id===player.emprestimo.destinationId ? `
      <div class="eyebrow" style="margin:14px 0 8px;">Empréstimo</div>
      <div class="pm-retro-row"><span class="lbl">Emprestado por</span><span class="val">${state.teams[player.emprestimo.ownerId]?teamLinkHtml(player.emprestimo.ownerId):"—"}</span></div>
      <div class="pm-retro-row"><span class="lbl">Regresso previsto</span><span class="val">Final desta época</span></div>
      <div class="pm-retro-row"><span class="lbl">Salário suportado pelo destino</span><span class="val">${player.emprestimo.salaryShare}%</span></div>
      <div class="pm-retro-row"><span class="lbl">Papel prometido</span><span class="val">${ROLE_LABELS[player.emprestimo.papel]||"—"}</span></div>
      <div class="pm-retro-row"><span class="lbl">Cláusulas</span><span class="val">${empClausulasTexto(player.emprestimo.clausulas)}</span></div>
      ` : `
      <div class="eyebrow" style="margin:14px 0 8px;">Empréstimo</div>
      <div class="pm-retro-row"><span class="lbl">Emprestado a</span><span class="val">${state.teams[player.emprestimo.destinationId]?teamLinkHtml(player.emprestimo.destinationId):"—"}</span></div>
      <div class="pm-retro-row"><span class="lbl">Cláusulas</span><span class="val">${empClausulasTexto(player.emprestimo.clausulas)}</span></div>
      `) : ''}
      ${!isMine && !isAcademyPlayer && !cedidoMeu ? (team.equipaPrincipalId ? `<div id="pmExternalTransferBox" style="margin-top:12px;">${externalLoanOnlyPanelHtml(player,team,myTeam())}</div>` : `<div id="pmExternalTransferBox" style="margin-top:12px;">${externalTransferPanelHtml(player,team,myTeam())}</div>`) : ''}
      ${isAcademyPlayer ? `<div class="pm-retro-subline" style="margin-top:10px;">Contrato de formação — sem ações de mercado/renovação enquanto o jogador estiver na Academia (${ACADEMY_BRACKET_LABEL[player.academyBracket]||player.academyBracket}).</div>` : ''}
      ${isMine && !player.emprestimo && !isAcademyPlayer ? `<div id="pmContractActions" style="margin-top:10px;">
        <button class="btn btn-ghost" id="pmRenewBtn">${state.uiNegotiationOpenId==='renov-'+player.id?'Fechar negociação':'Renegociar / Renovar'}</button>
        <button class="btn btn-ghost" id="pmReleaseBtn">Dispensar</button>
        ${teamId===state.userTeamId ? `<button class="btn btn-ghost" id="pmTransferListBtn">${player.transferListado?'Retirar do mercado':'Colocar no mercado'}</button>` : ''}
        ${teamId===state.userTeamId && player.transferListado ? `<div class="pm-retro-row" style="margin-top:8px;"><span class="lbl">No mercado por</span><span class="val">${fmtMoney(player.valorPedido)}</span></div>` : ''}
        ${(()=>{
          // Pedido do utilizador (2026-09-17): mover entre a equipa A e a equipa B tinha de
          // passar sempre pelo separador Mercado → Mercado Interno — nunca era possível a partir
          // da própria ficha do jogador, onde o utilizador já está a ver o jogador em questão.
          // Reutiliza tal como está internalTransferPairForUser/transferPlayerBetweenAandB
          // (08-evolucao-jogadores.js) — mesmas validações e efeitos (moral/satisfação),
          // só muda o sítio a partir de onde se pode acionar o movimento.
          const pair = internalTransferPairForUser();
          if(!pair) return '';
          if(teamId===pair.a.id) return `<button class="btn btn-ghost" id="pmMoveABBtn" data-target="${pair.b.id}">Descer para Equipa B</button>`;
          if(teamId===pair.b.id) return `<button class="btn btn-ghost" id="pmMoveABBtn" data-target="${pair.a.id}">Subir para Equipa A</button>`;
          return '';
        })()}
        <div id="pmContractNegBox" style="margin-top:8px;">${state.uiNegotiationOpenId==='renov-'+player.id ? negotiationCardHtml("renovacao", player, team, team, "Renovação", {forceOpen:true, hideToggle:true}) : ''}</div>
      </div>` : (isMine && player.emprestimo ? `<div class="market-status no" style="margin-top:10px;">Jogador emprestado por ${state.teams[player.emprestimo.ownerId]?teamLinkHtml(player.emprestimo.ownerId):"outro clube"} — o contrato pertence ao clube de origem, não pode ser renovado nem dispensado por ti.</div>` : '')}
    `;

    playerModalBox.style.maxWidth = "700px";
    playerModalBox.style.padding = "20px";
    playerModalBox.innerHTML = `
      ${playerModalHistory.length ? `<button class="pm-retro-back" id="pmBackBtn">← Voltar</button>` : ''}
      <div class="pm-retro">
        <div class="pm-retro-titlebar">
          <span class="ttl">${player.num}. ${playerNameHtml(player)} <button class="pm-retro-link" id="pmTeamLinkBtn" style="color:#B9C6EE;">(${team.name})</button></span>
          <span class="ovr">${isMine?evolutionArrowHtml(player,"ovr"):""}${visibleOverall(player,team)}</span>
        </div>
        <div class="pm-retro-tabs">
          <div class="pm-retro-tab ${pmActiveTab==='perfil'?'active':''}" data-tab="perfil">Perfil</div>
          <div class="pm-retro-tab ${pmActiveTab==='pessoal'?'active':''}" data-tab="pessoal">Pessoal</div>
          <div class="pm-retro-tab ${pmActiveTab==='historico'?'active':''}" data-tab="historico">Histórico</div>
        </div>
        <div class="pm-retro-body">${pmActiveTab==='perfil' ? perfilHtml : pmActiveTab==='pessoal' ? pessoalHtml : historicoHtml}</div>
        <div class="pm-retro-actions">
          <button id="pmCloseBtn">Fechar</button>
        </div>
      </div>
    `;
    playerModal.classList.remove("hidden");
    playerModalBox.scrollTop = isBack ? playerModalBox.scrollTop : 0;
    document.getElementById("pmCloseBtn").addEventListener("click", () => { playerModal.classList.add("hidden"); });
    document.getElementById("pmTeamLinkBtn").addEventListener("click", () => openClubFicha(team.id));
    document.querySelectorAll(".pm-retro-tab").forEach(t=>{
      t.addEventListener("click", () => renderPlayerModalContent(teamId, playerId, true, t.getAttribute("data-tab")));
    });
    const backBtn = document.getElementById("pmBackBtn");
    if(backBtn) backBtn.addEventListener("click", goBackPlayerModal);
    playerModalBox.querySelectorAll(".pm-retro-teammates button[data-id]").forEach(btn=>{
      btn.addEventListener("click", () => navigateToPlayer(btn.getAttribute("data-team"), btn.getAttribute("data-id")));
    });
    const titularEl = document.getElementById("pmTitular");
    if(titularEl){
      titularEl.addEventListener("change", () => {
        player.titular = titularEl.checked;
        renderRoster();
      });
    }
    const pmEstatutoEl = document.getElementById("pmEstatuto");
    if(pmEstatutoEl){
      pmEstatutoEl.addEventListener("change", () => {
        setPlayerEstatuto(player.id, team.id, pmEstatutoEl.value);
        renderPlayerModalContent(teamId, playerId, true, pmActiveTab);
        renderRoster();
      });
    }
    const pmRenewBtn = document.getElementById("pmRenewBtn");
    if(pmRenewBtn){
      pmRenewBtn.addEventListener("click", () => {
        const id = "renov-"+player.id;
        state.uiNegotiationOpenId = state.uiNegotiationOpenId===id ? null : id;
        renderPlayerModalContent(teamId, playerId, true, pmActiveTab);
      });
    }
    const pmReleaseBtn = document.getElementById("pmReleaseBtn");
    if(pmReleaseBtn){
      pmReleaseBtn.addEventListener("click", () => {
        if(!confirm("Dispensar este jogador? Ele fica disponível no mercado de jogadores livres.")) return;
        const r = releasePlayerToFreeAgency(player.id, team.id);
        if(!r.ok){ alert(r.reason); return; }
        playerModal.classList.add("hidden");
        renderRoster();
      });
    }
    const pmTransferListBtn = document.getElementById("pmTransferListBtn");
    if(pmTransferListBtn){
      pmTransferListBtn.addEventListener("click", () => {
        if(player.transferListado){
          if(!confirm("Retirar este jogador do mercado?")) return;
          clearPlayerTransferListed(player.id, team.id);
        } else {
          const suggestion = Math.round(playerMarketValue(player,team)/500)*500;
          const raw = prompt("Valor pedido por este jogador (€):", suggestion);
          if(raw===null) return;
          const value = parseInt(String(raw).replace(/[^0-9]/g,""),10);
          if(!Number.isFinite(value) || value<=0){ alert("Indica um valor válido."); return; }
          const r = setPlayerTransferListed(player.id, team.id, value);
          if(!r.ok){ alert(r.reason); return; }
        }
        renderPlayerModalContent(teamId, playerId, true, pmActiveTab);
        renderRoster();
      });
    }
    const pmCedidoMoveBtn = document.getElementById("pmCedidoMoveBtn");
    if(pmCedidoMoveBtn){
      pmCedidoMoveBtn.addEventListener("click", () => {
        const r = empMudarEquipaOrigem(player.id, pmCedidoMoveBtn.getAttribute("data-target"));
        if(!r.ok){ alert(r.reason); return; }
        renderPlayerModalContent(teamId, playerId, true, pmActiveTab);
        renderRoster();
      });
    }
    const pmMoveABBtn = document.getElementById("pmMoveABBtn");
    if(pmMoveABBtn){
      pmMoveABBtn.addEventListener("click", () => {
        const targetId = pmMoveABBtn.getAttribute("data-target");
        const result = transferPlayerBetweenAandB(player.id, team.id, targetId);
        if(!result.ok){ alert(result.reason); return; }
        playerModal.classList.add("hidden");
        renderRoster();
      });
    }
    const pmNegBox = document.getElementById("pmContractNegBox");
    if(pmNegBox){
      wireNegotiationCards(pmNegBox, () => renderPlayerModalContent(teamId, playerId, true, pmActiveTab));
    }
    const pmExternal=document.getElementById("pmExternalTransferBox");
    if(pmExternal) wireExternalTransferPanel(pmExternal,player,team,myTeam(),()=>renderPlayerModalContent(teamId,playerId,true,"pessoal"));
    const pmScoutBtn=document.getElementById("pmScoutRequestBtn");
    if(pmScoutBtn){
      pmScoutBtn.addEventListener("click", () => {
        const r = requestScoutingReport(player.id, team.id, "completo");
        if(!r.ok){ alert(r.reason); return; }
        renderPlayerModalContent(teamId, playerId, true, pmActiveTab);
      });
    }
    const pmScoutRapidoBtn=document.getElementById("pmScoutRequestRapidoBtn");
    if(pmScoutRapidoBtn){
      pmScoutRapidoBtn.addEventListener("click", () => {
        const r = requestScoutingReport(player.id, team.id, "rapido");
        if(!r.ok){ alert(r.reason); return; }
        renderPlayerModalContent(teamId, playerId, true, pmActiveTab);
      });
    }
  }

  // ============================= Pesquisa global (jogadores e clubes) =============================
  // Pedido do utilizador (2026-09-13): caixa de pesquisa na barra de navegação principal (sidebar
  // hub-nav), com resultados em tempo real. Âmbito confirmado nessa conversa: só os 42 clubes
  // portugueses (Placard/2.ª/3.ª Divisão) e os respetivos plantéis, mais os jogadores livres do
  // mercado — não inclui OK Liga, Serie A1, clubes da nuvem europeia, reformados/inativos nem
  // candidatos de formação ainda não promovidos ao plantel sénior.
  const PT_SEARCHABLE_DIVISIONS = ["placard","2div","3div"];
  const GLOBAL_SEARCH_DIVISION_LABEL = { "placard":"Placard", "2div":"2.ª Divisão", "3div":"3.ª Divisão" };
  function searchNormalize(s){
    return String(s||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase();
  }
  function globalSearchableClubs(){
    return Object.values(state.teams).filter(t=>PT_SEARCHABLE_DIVISIONS.includes(t.divisaoAtual));
  }
  function globalSearchablePlayers(){
    const out=[];
    globalSearchableClubs().forEach(t=>{
      t.players.forEach(p=>out.push({ id:p.id, teamId:t.id, teamName:t.name, name:p.name, pos:p.pos, freeAgent:false }));
    });
    (state.freeAgents||[]).forEach(p=>out.push({ id:p.id, teamId:null, teamName:"Agente livre", name:p.name, pos:p.pos, freeAgent:true }));
    return out;
  }
  function runGlobalSearch(query){
    const q = searchNormalize(query).trim();
    if(q.length<2) return { clubs:[], players:[] };
    const rank = (name)=>{ const n=searchNormalize(name); const idx=n.indexOf(q); return idx<0 ? 999 : (idx===0 ? 0 : 1); };
    const clubs = globalSearchableClubs()
      .map(t=>({ t, r:rank(t.name) }))
      .filter(x=>x.r<999)
      .sort((a,b)=>a.r-b.r || a.t.name.localeCompare(b.t.name))
      .slice(0,6)
      .map(x=>x.t);
    const players = globalSearchablePlayers()
      .map(p=>({ p, r:rank(p.name) }))
      .filter(x=>x.r<999)
      .sort((a,b)=>a.r-b.r || a.p.name.localeCompare(b.p.name))
      .slice(0,8)
      .map(x=>x.p);
    return { clubs, players };
  }
  function closeGlobalSearch(){
    const box = document.getElementById("globalSearchResults");
    if(box) box.classList.add("hidden");
  }
  // Os agentes livres não têm ficha de jogador universal (renderPlayerModalContent exige sempre
  // um clube com plantel) — em vez de construir uma ficha à parte só para este caso raro, salta-se
  // para o cartão de negociação já existente no Mercado (mesmo sítio onde já é possível contratá-lo).
  function goToFreeAgentInMarket(playerId){
    mercadoIrPara("livres");
    setView("mercado");
    setTimeout(()=>{
      const card = document.querySelector(`.negotiation-card[data-negid="${playerId}|livre-sign"]`);
      if(!card) return;
      card.scrollIntoView({ behavior:"smooth", block:"center" });
      card.classList.add("gsr-highlight");
      setTimeout(()=>card.classList.remove("gsr-highlight"), 1600);
    }, 0);
  }
  function renderGlobalSearchResults(query){
    const box = document.getElementById("globalSearchResults");
    if(!box) return;
    const trimmed = searchNormalize(query).trim();
    if(trimmed.length<2){
      box.innerHTML = `<div class="gsr-empty">Escreve pelo menos 2 letras…</div>`;
      box.classList.remove("hidden");
      return;
    }
    const { clubs, players } = runGlobalSearch(query);
    if(!clubs.length && !players.length){
      box.innerHTML = `<div class="gsr-empty">Sem resultados para "${escapeHtml(query.trim())}".</div>`;
    } else {
      box.innerHTML = `
        ${clubs.length ? `<div class="gsr-group-label">Clubes</div>${clubs.map(t=>`
          <button type="button" class="gsr-item" data-kind="club" data-team="${t.id}">
            <span>🏟️ ${escapeHtml(t.name)}</span>
            <span class="gsr-meta">${escapeHtml(GLOBAL_SEARCH_DIVISION_LABEL[t.divisaoAtual]||"")}</span>
          </button>`).join("")}` : ""}
        ${players.length ? `<div class="gsr-group-label">Jogadores</div>${players.map(p=>`
          <button type="button" class="gsr-item" data-kind="player" data-team="${p.teamId||""}" data-id="${p.id}" data-freeagent="${p.freeAgent?"1":"0"}">
            <span class="pos-badge ${p.pos==="GR"?"gr":"j"}">${p.pos==="GR"?"GR":"J"}</span>
            <span>${escapeHtml(p.name)}</span>
            <span class="gsr-meta">${escapeHtml(p.teamName)}</span>
          </button>`).join("")}` : ""}
      `;
    }
    box.classList.remove("hidden");
    box.querySelectorAll(".gsr-item").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        const kind = btn.getAttribute("data-kind");
        if(kind==="club"){
          openClubFicha(btn.getAttribute("data-team"));
        } else if(btn.getAttribute("data-freeagent")==="1"){
          goToFreeAgentInMarket(btn.getAttribute("data-id"));
        } else {
          openPlayerModal(btn.getAttribute("data-team"), btn.getAttribute("data-id"));
        }
        closeGlobalSearch();
        globalSearchInput.value = "";
      });
    });
  }
  const globalSearchInput = document.getElementById("globalSearchInput");
  if(globalSearchInput){
    globalSearchInput.addEventListener("input", ()=>renderGlobalSearchResults(globalSearchInput.value));
    globalSearchInput.addEventListener("focus", ()=>{ if(globalSearchInput.value.trim().length) renderGlobalSearchResults(globalSearchInput.value); });
    globalSearchInput.addEventListener("keydown", (e)=>{
      if(e.key==="Escape"){ closeGlobalSearch(); globalSearchInput.value=""; globalSearchInput.blur(); }
    });
    document.addEventListener("click", (e)=>{
      const wrap = document.getElementById("globalSearchWrap");
      if(wrap && !wrap.contains(e.target)) closeGlobalSearch();
    });
  }

  // =================================================================

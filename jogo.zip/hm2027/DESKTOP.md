# Hóquei Manager 2027 — versão desktop

O jogo corre dentro de uma janela própria (Tauri), sem barra de endereço nem separadores, com ícone próprio. O código do jogo (`index.html`, `css/`, `js/`, `img/`, `fonts/`, `database/`) é exatamente o mesmo da versão browser.

## Obter os instaladores (Windows, Mac, Linux)

1. Cria um repositório no GitHub (pode ser privado) e ativa o separador **Actions**.
2. Nesta pasta, num terminal:
   ```
   git init
   git add .
   git commit -m "HM2027 desktop"
   git branch -M main
   git remote add origin https://github.com/<utilizador>/<repositorio>.git
   git push -u origin main
   ```
3. No GitHub: **Actions → Compilar Hóquei Manager 2027 (desktop)**. Cada compilação demora ~10–15 min (a primeira é a mais lenta).
4. Quando terminar, abre a execução e descarrega os **Artifacts**: `instalador-Windows` (`.msi`/`.exe`), `instalador-macOS (Apple Silicon)` e `instalador-macOS (Intel)` (`.dmg`), `instalador-Linux` (`.deb`/`.AppImage`).
5. Para publicar uma versão com ligação de descarga: `git tag v0.1.0 && git push origin v0.1.0` — cria um *release* em rascunho com os instaladores anexados.

## Avisos na primeira abertura (a aplicação não está assinada)

- **Windows:** o SmartScreen pode avisar "Windows protegeu o seu PC" → *Mais informações → Executar mesmo assim*.
- **Mac:** clica com o botão direito na aplicação → *Abrir* (a primeira vez).

## Como se usa

- **F11** alterna o ecrã inteiro. O jogo arranca em ecrã inteiro.
- **Guardar / Carregar** usam um seletor dentro do próprio jogo (sem janelas do Windows). As gravações ficam em `Documentos\Hoquei Manager 2027\Saves` (a pasta é criada no primeiro arranque); diagnósticos e resumos exportados vão para `Documentos\Hoquei Manager 2027\Exportados`. Para passar gravações para outro computador, copia os ficheiros `.json` (e `.hmmeta`, opcional) para a mesma pasta; o botão "Abrir pasta" do seletor abre-a no Explorador.
- As ligações externas abrem no browser do sistema.

## Desenvolver / alterar o jogo

- O motor edita-se em `js/src/` e gera-se com `python3 js/build.py` (como antes).
- `node desktop/prepare.js` junta os ficheiros do jogo em `dist/` (o Tauri chama-o sozinho).
- Para testar localmente (precisa de Rust e Node): `npm install` e `npm run dev`.
- Para mudar nome/ícone: `src-tauri/tauri.conf.json` e `desktop/icon-source.png` (depois `npx tauri icon desktop/icon-source.png`).
- **Sair**: botão no menu inicial e na barra lateral (no jogo pergunta se queres guardar antes de sair).
- **Fundos**: as fotografias em `img/fundos/` rodam ao abrir o jogo e de vez em quando ao carregar em Continuar.

## Autosave e gravação atual (2026-10-13)

Definições › Gravações: autosave Nenhum / Semanal / Mensal (por omissão: Nenhum) e botão "Guardar como…". A aplicação lembra o ficheiro que gravaste (1.º Guardar) ou carregaste; os Guardar seguintes e o autosave substituem esse ficheiro. Sem ficheiro atual, o autosave grava em «Clube - Autosave». O autosave só existe na versão desktop. Durante o processamento (continuar, arranque de carreira, carregar, guardar) o cursor passa a ser um stick (`img/cursor/stick-*.png`).

## Versão portátil (Windows, sem administrador) — 2026-10-13

O workflow gera agora um segundo artefacto, `portatil-Windows`: uma pasta com `Hoquei Manager 2027.exe` + `LEIA-ME.txt`. O .exe do Tauri leva o jogo dentro, por isso basta extrair a pasta e abri-lo: não instala nada nem pede direitos de administrador. As gravações continuam em Documentos\Hoquei Manager 2027\Saves. Requisitos/avisos: precisa do WebView2 (já vem com o Windows 11 e com o Windows 10 atualizado); o SmartScreen pode avisar por o programa não estar assinado ("Mais informações" > "Executar mesmo assim", também sem administrador); políticas de empresa (AppLocker/antivírus) podem bloquear .exe desconhecidos. O instalador `.exe` (NSIS) passou a estar fixado em `installMode: currentUser` (instalação só para o utilizador, sem administrador); o `.msi` precisa sempre de administrador.
